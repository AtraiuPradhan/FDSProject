# QuantumPINN-Fin: research package

Wealth-floor-constrained Merton HJB; classically simulated 4-qubit circuit (B5) against a parameter-matched classical PINN (B2).
Nothing here uses quantum hardware. Main finding so far: B2 is more accurate than B5 at equal wall-clock; no advantage for B5 was found.

Setup: `pip install -r requirements.txt` (tested: Windows, Python 3.11, torch 2.11.0+cu128, numpy 2.4.6, pandas 3.1.0, scipy 1.17.1).
Run everything from this folder. First command: `python review3/check_setup.py`.

## Layout (one copy of everything)
| Folder | Contents |
|---|---|
| `paper/` | `QuantumPINN_Fin_Revised_Paper.docx`: the current paper (supersedes the earlier drafts) |
| `implementation/qpinn_fin/` | The library: Params, HJB residual and policy, FD reference solver, models B1-B5, trainer. Pilot outputs from Review 2 in `results/`. Not modified by Review 3 |
| `historical/` | French daily data (`data/`), `download_french_daily.py`, `walk_forward_backtest.py`, tests. `results/` is filled when you run the walk-forward. `results_review2/` = the three Review-2 summary CSVs [R2] |
| `review3/` | All Review-3 (P1/P2) scripts, outputs and records. Start with `review3/README.md` |
| `docs/` | Earlier project documents: policy-stability note, evidence audit, historical-study protocol (v1), research-direction note |
| `code/`, `results/` | Review-2 conditional-bound check (`check_policy_bound.py`, `validate_bound_on_pilot.py`) and its outputs |
| `REFERENCES.md` | Candidate sources (not all verified; see the paper's limitations) |

## Evidence tags
[S] reproduced on the authors' machine. [R2] from Review 2. [P] provisional, computed in a separate Linux environment (`review3/provisional/`, and `review3/provisional/fd_floor_check.json`). [X] not yet run.
`review3/REPRODUCIBILITY.md` lists every claim with its tag.

## Not in the package, by design
Trained model files, daily allocation paths and `historical/results/walk_forward_fold_results.csv` are produced by the walk-forward run (review3/README.md step 7). The FD reference cache is regenerated automatically on first use.
