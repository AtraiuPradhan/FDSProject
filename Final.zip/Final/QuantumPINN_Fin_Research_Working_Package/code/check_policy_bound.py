"""
Numerical sanity check for the pointwise clipped-policy perturbation bound.
Synthetic algebra check only; not a reproduction of the WF benchmark.
Requires numpy. Run: python code/check_policy_bound.py
"""
import numpy as np

SEED = 20261019
N = 100_000
rng = np.random.default_rng(SEED)
a, sigma = 0.06, 0.20
eps1, eps2 = 0.01, 0.05
wealth = rng.uniform(0.10, 2.0, size=N)
p = rng.uniform(-2.0, 2.0, size=N)
q = rng.choice([-1.0, 1.0], size=N) * rng.uniform(0.50, 3.0, size=N)
dp = rng.uniform(-eps1, eps1, size=N)
dq = rng.uniform(-eps2, eps2, size=N)
pt, qt = p + dp, q + dq

raw = -a * p / (sigma**2 * wealth * q)
raw_tilde = -a * pt / (sigma**2 * wealth * qt)
pi, pi_tilde = np.clip(raw, 0, 1), np.clip(raw_tilde, 0, 1)
observed = np.abs(pi_tilde - pi)

bound = abs(a) / (sigma**2 * wealth) * (
    eps1 / (np.abs(q) - eps2)
    + np.abs(p) * eps2 / (np.abs(q) * (np.abs(q) - eps2))
)
violations = int(np.count_nonzero(observed > bound + 1e-12))
print(f"seed={SEED}")
print(f"points={N}")
print(f"derivative_error_limits: eps1={eps1}, eps2={eps2}")
print(f"mean_pointwise_bound={bound.mean():.12g}")
print(f"max_pointwise_bound={bound.max():.12g}")
print(f"max_observed_policy_error={observed.max():.12g}")
print(f"mean_observed_policy_error={observed.mean():.12g}")
print(f"bound_violations={violations}")
if violations:
    raise SystemExit("FAIL: numerical inequality violation detected")
print("PASS: sampled cases satisfy the pointwise conditional bound.")
