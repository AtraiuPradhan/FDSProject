"""
Empirical check of the conditional policy perturbation bound on the uploaded P1 reference.
Run from the package root:
  python code/validate_bound_on_pilot.py
This trains a fresh seed-0 B2 model for 1500 steps. It is not a reproduction of
the later 30-seed WF experiment described in the tracker.
"""
import json, sys, time
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "implementation" / "qpinn_fin"))
from qpinn_fin.config import PRIMARY, problem_params
from qpinn_fin.trainer import train
from qpinn_fin.hjb import derivs, policy_raw
from qpinn_fin.reference import load_or_solve_fd

def main():
    p = problem_params("P1", PRIMARY)
    sol = load_or_solve_fd(p)
    method, seed, steps = "B2", 0, 1500
    model, info = train(method, p, seed=seed, steps=steps, log_every=300, verbose=False)
    observed, bounds, valid_all = [], [], []
    for ti, tv in enumerate(sol.t[:-1]):
        cgrid = np.exp(np.linspace(np.log(0.1), np.log(10.0), 120))
        ct = torch.tensor(cgrid, dtype=torch.float64)
        tt = torch.full_like(ct, float(tv))
        _, _, Vc, Vcc, cl, tl = derivs(model, ct, tt, create_graph=False)
        p_model = Vc.detach().numpy()
        q_model = Vcc.detach().numpy()
        raw_model = policy_raw(Vc, Vcc, cl, tl, p).detach().numpy()

        Vref, x, cref = sol.V[ti], sol.x, sol.c
        Vx = np.gradient(Vref, x, edge_order=2)
        Vxx = np.gradient(Vx, x, edge_order=2)
        p_ref = np.interp(np.log(cgrid), x, Vx / cref)
        q_ref = np.interp(np.log(cgrid), x, (Vxx - Vx) / (cref ** 2))
        wealth = cgrid + p.F * np.exp(-p.r * (p.T - float(tv)))
        a, sigma = p.mu - p.r, p.sigma

        pi_ref = np.clip(-a * p_ref / (sigma**2 * wealth * q_ref), 0, 1)
        pi_model = np.clip(raw_model, 0, 1)
        err_policy = np.abs(pi_model - pi_ref)
        eps1 = np.abs(p_model - p_ref)
        eps2 = np.abs(q_model - q_ref)
        valid = (np.abs(q_ref) > eps2) & np.isfinite(q_ref) & np.isfinite(q_model) & (wealth > 0)

        bound = np.full_like(wealth, np.nan, dtype=float)
        bound[valid] = abs(a) / (sigma**2 * wealth[valid]) * (
            eps1[valid] / (np.abs(q_ref[valid]) - eps2[valid])
            + np.abs(p_ref[valid]) * eps2[valid]
            / (np.abs(q_ref[valid]) * (np.abs(q_ref[valid]) - eps2[valid]))
        )
        observed.extend(err_policy.tolist())
        bounds.extend(bound.tolist())
        valid_all.extend(valid.tolist())

    obs, bnd, valid = np.asarray(observed), np.asarray(bounds), np.asarray(valid_all, dtype=bool)
    obs_valid, bnd_valid = obs[valid], bnd[valid]
    result = {
        "status": "exploratory single-seed check",
        "problem": "P1",
        "method": method,
        "seed": seed,
        "training_steps": steps,
        "n_params": info["n_params"],
        "train_time_seconds": info["train_time"],
        "evaluation_points": int(len(obs)),
        "points_satisfying_curvature_condition": int(valid.sum()),
        "valid_fraction": float(valid.mean()),
        "policy_rmse_against_derivative_based_reference": float(np.sqrt(np.mean(obs**2))),
        "mean_observed_policy_error_on_valid_points": float(obs_valid.mean()),
        "mean_bound_on_valid_points": float(bnd_valid.mean()),
        "median_bound_on_valid_points": float(np.median(bnd_valid)),
        "max_bound_on_valid_points": float(bnd_valid.max()),
        "bound_violations_tolerance_1e-8": int(np.sum(obs_valid > bnd_valid + 1e-8)),
        "limitations": [
            "Reference derivatives are finite-difference estimates derived from the cached FD value grid.",
            "Only B2, seed 0, and one training budget were tested.",
            "This does not validate a theorem over a continuum or establish novelty.",
            "This is classical statevector simulation, not a quantum hardware experiment."
        ]
    }
    out = ROOT / "results" / "pilot_bound_validation_B2_seed0.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
