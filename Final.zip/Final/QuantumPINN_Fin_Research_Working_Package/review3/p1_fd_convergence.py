"""P1: FD convergence across all folds / regimes and across the whole (c, t) domain (not only rebalance points).

For every test year the FD policy is solved on four grids (coarse 120x6000, default 240x12000, fine 360x18000, finest 480x32000 = reference; Nt is raised
to the explicit-scheme stability bound when needed and this is recorded) and compared with the FINEST grid (480x32000) on a dense
log-cushion grid c in [0.1, 4.0] at all 40 saved time slices. The solver's two end nodes (pi := 0 by construction) are excluded.
Errors are reported over all states, over the transition zone (0.02 < pi < 0.98, where the free boundary lives) and separately by regime.
Run: python review3/p1_fd_convergence.py [--data PATH] [--years 2000 2001 ...]
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from r3_common import OUT_DEFAULT, YEARS, fold_params, load_data, regime_of, stable_nt
from qpinn_fin.reference import solve_fd

GRIDS = {"coarse": (120, 6000), "default": (240, 12000), "fine": (360, 18000), "finest": (480, 32000)}   # finest = reference


def field(sol, cg):
    return np.clip(np.array([np.interp(np.log(cg), sol.x, sol.pi[i]) for i in range(len(sol.t))]), 0, 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=None); ap.add_argument("--out", default=str(OUT_DEFAULT))
    ap.add_argument("--years", nargs="+", type=int, default=YEARS)
    a = ap.parse_args()
    out = OUT_DEFAULT if a.out is None else __import__("pathlib").Path(a.out); out.mkdir(parents=True, exist_ok=True)
    df = load_data(a.data)
    cg = np.geomspace(0.1, 4.0, 300)
    rows = []
    for year in a.years:
        p = fold_params(df, year)
        sols, raised = {}, {}
        for tag, (nx, nt) in GRIDS.items():
            nt_eff = stable_nt(p, nx, nt, 40)
            raised[tag] = nt_eff != nt
            sols[tag] = solve_fd(p, cap=True, Nx=nx, Nt=nt_eff, n_save=40)
        ref = field(sols["finest"], cg)
        zone = (ref > 0.02) & (ref < 0.98)
        for tag in ("coarse", "default", "fine"):
            e = np.abs(field(sols[tag], cg) - ref)
            rows.append(dict(year=year, grid=tag, nx=GRIDS[tag][0], nt_requested=GRIDS[tag][1], nt_raised_for_stability=raised[tag],
                             pi_M=p.merton_fraction, sigma=p.sigma, regime=regime_of(p.merton_fraction),
                             transition_fraction=float(zone.mean()), mae_all=float(e.mean()), rmse_all=float(np.sqrt((e ** 2).mean())),
                             max_all=float(e.max()), max_transition=float(e[zone].max()) if zone.any() else np.nan,
                             mae_transition=float(e[zone].mean()) if zone.any() else np.nan))
        print(year, regime_of(p.merton_fraction), f"max_all vs finest: coarse={rows[-3]['max_all']:.3g} default={rows[-2]['max_all']:.3g} fine={rows[-1]['max_all']:.3g}", flush=True)
    cv = pd.DataFrame(rows)
    cv.to_csv(out / "fd_convergence_all_folds.csv", index=False)
    summ = cv.groupby(["grid", "regime"]).agg(folds=("year", "count"), transition_fraction=("transition_fraction", "mean"),
                                              mae_all=("mae_all", "mean"), max_all=("max_all", "max"),
                                              max_transition=("max_transition", "max"), nt_raised=("nt_raised_for_stability", "sum")).reset_index()
    summ.to_csv(out / "fd_convergence_by_regime.csv", index=False)
    w = cv.pivot(index="year", columns="grid", values="max_all")
    w["ratio_coarse_over_default"] = w["coarse"] / w["default"]
    mae = cv.pivot(index="year", columns="grid", values="mae_all")
    print("\nobserved order from MAE (coarse->default, default->fine; 1 = first order, 2 = second order, reference=finest):")
    print(pd.DataFrame({"order_120_240": np.log(mae["coarse"] / mae["default"]) / np.log(2),
                        "order_240_360": np.log(mae["default"] / mae["fine"]) / np.log(1.5)}).replace([np.inf, -np.inf], np.nan).describe().loc[["count","mean","50%"]].to_string())
    print(summ.to_string(index=False))
    print("\nratio coarse/default of max error (a ratio >1 means the error shrinks with refinement):")
    print(w["ratio_coarse_over_default"].describe().to_string())


if __name__ == "__main__":
    main()