# Review-3 scripts and outputs

Run from the package root (the folder that contains `implementation/`, `historical/` and `review3/`). Nothing outside `review3/` is modified.
Needs python, torch, numpy, pandas, scipy (`requirements.txt` at the root). Data: `historical/data/french_daily_market_rf.csv` (or pass `--data`).
Ablation runs are resumable. `bash review3/run_all.sh` (or `powershell -ExecutionPolicy Bypass -File review3\run_all.ps1`) runs steps 1-6 in order.

## Run order
| step | command | output folder | time |
|---|---|---|---|
| 0 | `python review3/check_setup.py` and `python review3/test_stress_margin.py` | | seconds |
| 1 | `python review3/p1_hjb_validation.py` | `out/` | seconds |
| 2 | `python review3/p1_fd_stability_audit.py`, then `python review3/p1_fd_convergence.py` | `out/` | ~1 + ~5 min |
| 3 | init control: `python review3/p1_ablation.py --preset init --base-year Y --seeds 0 1 2 3 4 --workers 2` for Y = 2006, 2014, 2008 | `out/` | ~3 min each |
| 4 | equal wall-clock: `--preset eqtime --seeds 0 1 2 3 4 --workers 2` | `out/` | ~10 min |
| 5 | core ablation: `--preset core --base-year Y --seeds 0 1 2 3 4 --workers 2` for Y = 2006, 2014, 2008 | `out/` | ~1 h each |
| 6 | 5,000 steps: `--preset init --base-year Y --seeds 0 1 2 --steps 5000 --workers 2 --out review3/out_5000` for Y = 2014, 2008 | `out_5000/` | ~15 min each |
| 7 | fresh-fold test (E10): `--preset followup --base-year Y --steps 5000 --seeds 0 1 2 --workers 2 --out review3/out_followup` for Y = 2016, 2020, 2022 | `out_followup/` | ~30-60 min each |
| 8 | sweeps (E11): `--preset regimes --seeds 0 1 2 --workers 2 --out review3/out_sweeps`, then `--preset floor gamma --base-year 2014 --seeds 0 1 2 --workers 2 --out review3/out_sweeps` | `out_sweeps/` | ~1-2 h |
| 9 | FD reference check (E12): `python review3/p1_fd_floor_check.py` | `out/fd_floor_check.json` | a few minutes |
| 10 | walk-forward: `python historical/walk_forward_backtest.py --seeds 0 1 2 3 4 --methods B2 B5` (see `historical/README.md`) | `historical/results/` | hours |
| 11 | `python review3/p1_paired_ci.py --fold-csv historical/results/walk_forward_fold_results.csv`, then `python review3/p1_stress.py --results-dir historical/results --methods B2 B5 --seed 0` | `out/` | minutes + 10-30 min |
| 12 | `python review3/record_environment.py` (writes `out/environment_manifest.json`); compare the SHA-256 of the retained French ZIP with the paper | `out/` | seconds |

Re-summarise any ablation folder without rerunning it: `python review3/p1_ablation.py --summarize-only --out review3/<folder>`.
Timing-dependent results (`B2_eqtime`, `B2_eqtime_up1`) depend on the CPU; quote `steps_done`, not `steps`.

## What is in the folder
- `out/`, `out_5000/`, `out_followup/`, `out_sweeps/`: [S] results (`ablation.jsonl` = raw rows, `ablation_summary.csv`, `ablation_paired_diffs.csv`; `out/` also has the HJB-validation and FD files).
- `provisional/`: [P] numpy evidence from the Linux environment (walk-forward baselines rerun, regimes, paired bootstrap, gap-shock test, FD check). Superseded by `p1_paired_ci.py` and `p1_stress.py` once step 10-11 are done.
- `REPRODUCIBILITY.md`: chronology, settings, reproduced results, corrections, claim ledger.
- `r3_common.py`, `r3_models.py`, `r3_train.py`: shared code.

## Reviewer item -> script -> output
| Item | Script | Output |
|---|---|---|
| HJB policy and clipping validation | `p1_hjb_validation.py` | `out/hjb_validation.json` |
| Loss and architecture ablations | `p1_ablation.py` | `ablation_summary.csv`, `ablation_paired_diffs.csv` |
| B2 vs B5 under matched parameter and compute budgets | `p1_ablation.py` | variants `B2` (51 params), `B5` (53), `B2m_L*`, `B2_eqtime`, `B2_eqtime_up1` |
| PDE residual and boundary errors | `p1_ablation.py` | `hjb_resid_*`, `bc_lo_*`, `bc_hi_*`, `policy_*`, `value_rel_l2` |
| FD convergence | `p1_fd_stability_audit.py`, `p1_fd_convergence.py`, `p1_fd_floor_check.py` | `out/fd_*.csv`, `out/fd_floor_check.json` |
| Paired CIs | `p1_paired_ci.py` | `out/paired_strategy_comparisons.csv` |
| Floor stress tests | `p1_stress.py` | `out/stress_summary*.csv` |
| Other gamma, floor, regimes | `p1_ablation.py --preset gamma floor regimes` | `out_sweeps/` |

## Variants
`B5` (4 qubits, 4 layers, data re-uploaded every layer); `B2` (MLP, 51 params); `B2_eqtime` (B2 for B5's wall-clock); `B2_noHJB`, `B5_noHJB` (no residual loss); `B2_noBC`; `B1`, `B4` (penalty instead of constraint-consistent); `B3` (no entanglers); `B5_L1/L2/L6` with matched `B2m_L*`; `B5_L4_up1/up2` (re-upload only in the first 1 or 2 layers); `B2_eqtime_up1` (B2 for `B5_L4_up1`'s wall-clock; E10 only); `B2_init`, `B5_init` (untrained controls).

## Read before interpreting
1. The trial form V = u(c) exp((T-t) S) with S squashed to a window built from the analytic boundary exponents carries analytic knowledge of the solution: both models learn a correction, not the whole value function.
2. 500 steps under-trains B2 in cap-binding folds. "Untrained beats trained" holds only at 500 steps.
3. Terminal error is zero by construction; report boundary error instead.
4. The FD reference is converged in the mean but has about 1e-3 maximum error at the free-boundary kink. At gamma = 5 and 10 the shared model error is the default grid's smooth bias, not the kink (`out/fd_floor_check.json`, [P] copy in `provisional/`).
5. Folds in the sweeps are not independent evidence: five floor levels or six gammas on fold 2014 are one market fold. Nine distinct folds in total; the B5-vs-B2 conclusion rests on two cap-binding folds (2008, 2014) plus the three fresh folds of E10 for the partial re-upload variant.
6. Sharpe is NaN where a policy is 100% cash. A -70% one-day move is a design limit of the pi <= 1 cap, not a historical event.
