"""P1: pathwise floor protection under severe market shocks, volatility spikes and parameter-estimation error.

For every test year (fold) the project's own `simulate()` is used with the fold's estimated parameters. Policies:
  fd_reference, trained B2 / B5 (loaded from model_<year>_<method>_seed<k>.pt written by walk_forward_backtest.py),
  fixed_50, market_100, and (FD only) fd_misspec (policy solved with mu+shift and sigma*mult, i.e. wrong parameters).
Scenarios
  history     : the actual returns of the year (also run with other floors F: fd_F<value> policies, FD only)
  gap_<x>     : the market return on one day is replaced by x (e.g. -0.30); repeated for many days of the year
  volspike    : demeaned returns x3 over a 40-day window starting at several dates
Floor metrics: terminal breach (wealth_T < F) AND pathwise breach (wealth_t < F exp(-r(T-t)) at ANY day) and the worst margin.
Everything is also split by regime of the fold's Merton fraction (pi_M<0, 0..1, >1).
Run: python review3/p1_stress.py --results-dir historical/results --methods B2 B5 --seed 0
     python review3/p1_stress.py --methods none        # FD + baselines only, no trained models needed
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from r3_common import OUT_DEFAULT, ROOT, YEARS, fold_params, fold_split, load_data, regime_of, solve_fd_stable, wfb
from qpinn_fin.config import Params
from qpinn_fin.models import build
from qpinn_fin.trainer import boundary_exponents


def load_policy(results_dir: Path, year: int, method: str, seed: int, p: Params):
    f = results_dir / f"model_{year}_{method}_seed{seed}.pt"
    if not f.exists():
        return None
    model = build({"B2": "mlp", "B5": "quantum"}[method], p, boundary_exponents(p), 4, 4)
    model.load_state_dict(torch.load(f, map_location="cpu"))
    model.eval()
    return lambda c, t, m=model, pp=p: wfb.model_policy(m, pp, c, t)


def run_one(te, p, strat, policy, cost_rate=10 / 1e4, rebal=21):
    """Returns (terminal wealth, worst pathwise margin).

    Margin checks, with the discounted floor evaluated at the SAME instant as the wealth it is compared with:
      - after trading cost, start of day i :  (wealth_start - cost_amount) - F exp(-r (T - t_i)),            t_i = i/252
      - end of day i                       :  wealth_end - F exp(-r (T - t_{i+1})),                          t_{i+1} = min((i+1)/252, T)
      - terminal                           :  wealth_T - F      (same test simulate() uses for terminal_floor_breach)
    so pathwise breach is never weaker than terminal breach.
    """
    met = wfb.simulate(te, p, strat, policy, rebal, cost_rate, save_path=True)
    rows = met.pop("allocation_path")
    m = []
    for i, r in enumerate(rows):
        t0 = r["time_years"]
        t1 = min((i + 1) / 252, p.T)
        m.append((r["wealth_start"] - r["cost_amount"]) - p.F * np.exp(-p.r * (p.T - t0)))
        m.append(r["wealth_end"] - p.F * np.exp(-p.r * (p.T - t1)))
    m.append(rows[-1]["wealth_end"] - p.F)
    return met["terminal_wealth"], float(min(m))


def apply_gap(te, day, x):
    te2 = te.copy()
    te2.loc[day, "market_total"] = x
    te2.loc[day, "mkt_rf"] = x - te2.loc[day, "rf"]
    return te2


def apply_spike(te, start, length=40, mult=3.0):
    te2 = te.copy()
    seg = te2.loc[start:start + length - 1, "market_total"]
    new = seg.mean() + mult * (seg - seg.mean())
    te2.loc[start:start + length - 1, "market_total"] = new
    te2.loc[start:start + length - 1, "mkt_rf"] = new - te2.loc[start:start + length - 1, "rf"]
    return te2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=None); ap.add_argument("--out", default=str(OUT_DEFAULT))
    ap.add_argument("--results-dir", default=str(ROOT / "historical" / "results"))
    ap.add_argument("--methods", nargs="+", default=["B2", "B5"], help="B2 B5, or 'none'")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--years", nargs="+", type=int, default=YEARS)
    ap.add_argument("--shocks", nargs="+", type=float, default=[-0.10, -0.20, -0.30, -0.50, -0.70])
    ap.add_argument("--days-step", type=int, default=20, help="spacing of shock days (smaller = more scenarios, slower)")
    ap.add_argument("--misspec-mu-shift", type=float, default=0.10)
    ap.add_argument("--misspec-sigma-mult", type=float, default=0.5)
    ap.add_argument("--floors", nargs="+", type=float, default=[0.6, 0.8, 0.9], help="extra floor levels (FD policy only)")
    ap.add_argument("--no-extra-floors", action="store_true")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    df = load_data(a.data)
    methods = [] if a.methods == ["none"] else a.methods
    days = list(range(5, 245, a.days_step))
    rows = []
    for year in a.years:
        tr, te = fold_split(df, year)
        p = fold_params(df, year)
        reg = regime_of(p.merton_fraction)
        sol = solve_fd_stable(p)
        pols = {"fd_reference": (lambda c, t, s=sol: wfb.fd_policy(s, c, t), "fd_reference"),
                "fixed_50": (None, "fixed_50"), "market_100": (None, "market_100")}
        for m in methods:
            pol = load_policy(Path(a.results_dir), year, m, a.seed, p)
            if pol is None:
                print(f"  [{year}] no saved model for {m}_seed{a.seed}; skipped")
            else:
                pols[f"{m}_seed{a.seed}"] = (pol, "fd_reference")     # strategy label only selects the policy_fn branch in simulate()
        pm = Params(mu=p.mu + a.misspec_mu_shift, r=p.r, sigma=max(p.sigma * a.misspec_sigma_mult, 0.03), gamma=p.gamma, T=p.T,
                    F=p.F, cmin=p.cmin, cmax=p.cmax)
        solm = solve_fd_stable(pm)
        pols["fd_misspec"] = (lambda c, t, s=solm: wfb.fd_policy(s, c, t), "fd_reference")
        scen = [("history", None, None)] + [(f"gap_{x:+.2f}", x, d) for x in a.shocks for d in days]
        rng = np.random.default_rng(year)
        starts = [int(s) for s in rng.integers(20, len(te) - 60, 6)]
        scen += [("volspike_x3_40d", "spike", s) for s in starts]
        for name, x, d in scen:
            te2 = te if x is None else (apply_spike(te, d) if x == "spike" else apply_gap(te, d, x))
            for pname, (pol, strat) in pols.items():
                tw, mg = run_one(te2, p, strat, pol)
                rows.append(dict(year=year, regime=reg, scenario=name, day=d, policy=pname, floor=p.F, terminal=tw, margin=mg))
        if not a.no_extra_floors:                                 # FD policy re-solved at higher floors (cushion shrinks)
            for F in a.floors:
                pF = Params(mu=p.mu, r=p.r, sigma=p.sigma, gamma=p.gamma, T=p.T, F=F, cmin=p.cmin, cmax=p.cmax)
                solF = solve_fd_stable(pF)
                polF = lambda c, t, s=solF: wfb.fd_policy(s, c, t)
                for name, x, d in [("history", None, None)] + [(f"gap_{x:+.2f}", x, d) for x in a.shocks if x <= -0.2 for d in days]:
                    te2 = te if x is None else apply_gap(te, d, x)
                    for pname, pol, strat in ((f"fd_F{F}", polF, "fd_reference"), (f"fixed_50_F{F}", None, "fixed_50"),
                                              (f"market_100_F{F}", None, "market_100")):
                        tw, mg = run_one(te2, pF, strat, pol)
                        rows.append(dict(year=year, regime=reg, scenario=name, day=d, policy=pname, floor=F, terminal=tw, margin=mg))
        print(f"fold {year} ({reg}) done", flush=True)
    r = pd.DataFrame(rows)
    r["terminal_breach"] = r.terminal < r.floor
    r["pathwise_breach"] = r.margin < 0
    r.to_csv(out / "stress_detail.csv.gz", index=False)
    agg = dict(n=("terminal", "size"), terminal_breach_rate=("terminal_breach", "mean"), pathwise_breach_rate=("pathwise_breach", "mean"),
               worst_margin=("margin", "min"), mean_terminal=("terminal", "mean"), min_terminal=("terminal", "min"))
    s_all = r.groupby(["scenario", "policy"]).agg(**agg).reset_index()
    s_reg = r.groupby(["regime", "scenario", "policy"]).agg(**agg).reset_index()
    s_all.to_csv(out / "stress_summary.csv", index=False); s_reg.to_csv(out / "stress_summary_by_regime.csv", index=False)
    with pd.option_context("display.width", 220, "display.max_rows", 600, "display.float_format", "{:.4g}".format):
        print(s_all.to_string(index=False))
    print(f"\nWrote stress_summary.csv, stress_summary_by_regime.csv, stress_detail.csv.gz in {out}")


if __name__ == "__main__":
    main()
