"""Writes review3/out/environment_manifest.json: software versions, hardware, dataset hash, and SHA-256 of every source file used.

Run once per experiment session, from the package root:   python review3/record_environment.py
Attach the JSON to any results you report. Two result sets are comparable only if the library versions and hashes below match
(timing-dependent results, e.g. equal-runtime step counts, also depend on the CPU).
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "review3" / "out"


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def version(mod: str) -> str:
    try:
        return __import__(mod).__version__
    except Exception as e:                                  # noqa: BLE001
        return f"unavailable ({type(e).__name__})"


info = {
    "recorded_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
    "python": sys.version.replace("\n", " "),
    "platform": platform.platform(),
    "machine": platform.machine(),
    "processor": platform.processor(),
    "cpu_count_logical": os.cpu_count(),
    "packages": {m: version(m) for m in ("torch", "numpy", "pandas", "scipy")},
}
try:
    import torch
    info["torch"] = {"num_threads_default": torch.get_num_threads(), "cuda_available": torch.cuda.is_available(),
                     "default_dtype_note": "qpinn_fin.models sets float64 globally"}
except Exception:                                           # noqa: BLE001
    pass

csv = ROOT / "historical" / "data" / "french_daily_market_rf.csv"
if csv.exists():
    import pandas as pd
    d = pd.read_csv(csv, parse_dates=["date"])
    info["dataset"] = {"path": "historical/data/french_daily_market_rf.csv", "sha256": sha256(csv), "rows": int(len(d)),
                       "first_date": str(d.date.min().date()), "last_date": str(d.date.max().date()), "columns": list(d.columns)}
else:
    info["dataset"] = "MISSING"

files = sorted(list((ROOT / "implementation" / "qpinn_fin" / "qpinn_fin").glob("*.py")) + [ROOT / "historical" / "walk_forward_backtest.py"]
               + list((ROOT / "review3").glob("*.py")) + list((ROOT / "review3").glob("*.md")))
info["source_sha256"] = {str(f.relative_to(ROOT)).replace("\\", "/"): sha256(f) for f in files}
outputs = sorted(OUT.glob("*.jsonl")) + sorted(OUT.glob("*.csv")) if OUT.exists() else []
info["existing_result_files_sha256"] = {str(f.relative_to(ROOT)).replace("\\", "/"): sha256(f) for f in outputs}

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "environment_manifest.json").write_text(json.dumps(info, indent=2))
print(json.dumps({k: v for k, v in info.items() if k not in ("source_sha256", "existing_result_files_sha256")}, indent=2))
print(f"\n{len(info['source_sha256'])} source files hashed -> {OUT / 'environment_manifest.json'}")
