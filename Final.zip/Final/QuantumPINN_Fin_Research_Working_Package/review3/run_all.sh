#!/usr/bin/env bash
# run from the package root: bash review3/run_all.sh   (stops at the first failure; steps 1-9 of review3/README.md, then 11 if walk-forward results exist)
set -e
python review3/check_setup.py
python review3/test_stress_margin.py
python review3/p1_hjb_validation.py
python review3/p1_fd_stability_audit.py
python review3/p1_fd_convergence.py
for y in 2006 2014 2008; do python review3/p1_ablation.py --preset init --base-year $y --seeds 0 1 2 3 4 --workers 2; done
echo "Inspect the init results before continuing (press Ctrl-C to stop)"; sleep 20
python review3/p1_ablation.py --preset eqtime --seeds 0 1 2 3 4 --workers 2
for y in 2006 2014 2008; do python review3/p1_ablation.py --preset core --base-year $y --seeds 0 1 2 3 4 --workers 2; done
for y in 2014 2008; do python review3/p1_ablation.py --preset init --base-year $y --seeds 0 1 2 --steps 5000 --workers 2 --out review3/out_5000; done
for y in 2016 2020 2022; do python review3/p1_ablation.py --preset followup --base-year $y --steps 5000 --seeds 0 1 2 --workers 2 --out review3/out_followup; done
python review3/p1_ablation.py --preset regimes --seeds 0 1 2 --workers 2 --out review3/out_sweeps
python review3/p1_ablation.py --preset floor gamma --base-year 2014 --seeds 0 1 2 --workers 2 --out review3/out_sweeps
python review3/p1_fd_floor_check.py
if [ -f historical/results/walk_forward_fold_results.csv ]; then
  python review3/p1_paired_ci.py --fold-csv historical/results/walk_forward_fold_results.csv
  python review3/p1_stress.py --results-dir historical/results --methods B2 B5 --seed 0
else
  echo "Skipping paired CIs and stress test: run the walk-forward first (review3/README.md step 10)"
fi
python review3/record_environment.py
