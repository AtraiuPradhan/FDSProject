# Review-3 reproducibility record (QuantumPINN-Fin)

This document records how the Review-3 (P1) evidence was produced, in what order, on which machines, with which settings,
what was corrected on the way, and which claims have been reproduced. Anything not listed under "Reproduced on the student machine"
should be treated as unconfirmed.

Status date: 31 Oct 2026. Companion files: `README.md` (how to run, in this folder), `out/environment_manifest.json` (created by `record_environment.py`), `../paper/QuantumPINN_Fin_Revised_Paper.docx` (current paper; its experiment IDs E1-E12 map to R1-R11 and the FD check below).

---------------------------------------------------------------------------------------------------------------------------------

## 1. Starting point

| Item | Detail |
|---|---|
| Reviewer request | Faculty review of Review-2 (email of 21 Oct), P1 items: HJB derivation / constrained solution, ablations, matched parameter and compute budgets, PDE and boundary errors, FD convergence across regimes, paired CIs, stress tests |
| Input package | `Review2.zip`: paper draft, `results/` (three summary CSVs), figures, `french_daily_market_rf.csv`, and a nested `QuantumPINN_Fin_Historical_Research_Package_Updated.zip` (qpinn_fin code, historical backtest script, tests) |
| Not in the input package (still not in this package until the walk-forward is run) | Fold-level results (`walk_forward_fold_results.csv`), trained models (`model_*.pt`), daily allocation paths. This is the gap the reviewer flagged ("raw per-fold results are not in the top-level results folder") |
| Original code | Not modified at any point. All new code is in `review3/` and imports the original modules |

### Data
* Source: Kenneth R. French Data Library, daily Fama/French factors (market excess return, risk-free), converted to decimals.
* File used: `french_daily_market_rf.csv`, 26,317 rows, 1926-07-01 to 2026-08-31, SHA-256
  `12aa55cd9e01c5ed08ea20c8693f4050ac1ff7f773dfe6e9bfd72e27fccc68c9`.
* The paper quotes SHA-256 `2f29e225...13a7db`. It does not match this file, most likely because it is the hash of the raw downloaded ZIP
  (the download script retains the ZIP). **Unverified**: confirm against the retained ZIP before claiming exact provenance.

## 2. Fixed experimental settings (taken from the original code, not chosen here)

* Walk-forward folds 2000-2025 (26), parameters re-estimated on the preceding 5 calendar years (`estimate_params`):
  r = 252 x mean(rf), mu = r + 252 x mean(mkt_rf), sigma = sqrt(252) x std(market_total, ddof=1).
* gamma = 2, T = 1, floor F = 0.30, cushion domain [0.05, 5], rebalance every 21 days, 10 bp cost on |change in risky weight|.
* FD reference: `qpinn_fin.reference.solve_fd` (explicit scheme, log-cushion grid), default 240 x 12,000, 40 saved times.
* Models: B2 = MLP (2 hidden layers, width chosen to match B5's parameter count: 51 vs 53 parameters); B5 = 4-qubit, 4-layer data-reuploading
  statevector circuit with ring entanglers, simulated classically (no hardware). Both: trial form V = u(c) exp((T-t) S), S squashed to a window
  built from the analytic boundary exponents (so the trial form carries analytic knowledge of the solution; report this as inductive bias).
* Training (`review3/r3_train.py`, mirrors `qpinn_fin.trainer.train` and the historical script): Adam, lr 1e-2, exponential decay x0.1 over the run,
  gradient clip 10, 192 interior + 32 boundary samples per step, loss = PDE residual (normalised by |u|) + boundary term, default 500 steps.
  `torch.manual_seed(seed)` and a sampling generator seeded `seed + 12345`.
* Evaluation (`evaluate_model`): held-out grid c in [0.1, 0.8 x cmax] (200 log-spaced points) at all saved FD times except T; 4,000 random
  held-out points (seed 999) for the HJB residual; FD solver end nodes excluded (the solver sets pi = 0 there by construction);
  "transition zone" = reference policy in (0.02, 0.98).
* "Equal-runtime" B2 (`B2_eqtime`): B5 is trained first for each seed; B2 then trains until it has used the same measured **training** wall-clock
  (timer excludes model construction and evaluation). The learning rate decays over the time budget. Actual update count is `steps_done` in
  the JSONL (`steps` stays at the requested 500).

## 3. Chronology: how the evidence was built

| # | Step | Where | Result / outcome |
|---|---|---|---|
| 1 | Read the review and the Review-2 package | sandbox (Linux, 2 CPU) | Mapped each reviewer point to existing evidence or a gap |
| 2 | Numpy-only rerun of FD reference + baselines for all 26 folds (`rerun_fd_baselines.py`) | sandbox | Reproduced the reported `walk_forward_summary.csv` rows for FD, constant Merton, fixed 50%, market, cash to the printed precision |
| 3 | First evidence pass (`review3_evidence.py`): regime counts, floor-vacuity, paired bootstrap, gap-shock test | sandbox | Findings in section 5. **Its stress numbers use the earlier pathwise-margin definition and are superseded by `p1_stress.py`** |
| 4 | P1 code v1 written and smoke-tested with short runs | sandbox | All scripts ran end to end (30-60 training steps only) |
| 5 | Independent audit of v1 by the student (via a second reviewer) | n/a | Four issues raised (paired-CI means, statistical wording, FD stability check, pathwise margin). All four verified as valid and fixed (section 6) -> v2 |
| 6 | Untrained controls and cap-binding folds added; init experiment run | sandbox then student machine | Section 5, results R4-R6 |
| 7 | Equal-runtime experiment added (v3) and run | sandbox (3 seeds) then student machine (5 seeds) | R7 |
| 8 | Student ran the setup check, unit test, validation, FD audit, FD convergence, init (3 folds), eqtime, core (folds 2006, 2014, 2008), 5,000-step check | **student machine (Windows, Python 3.11, torch 2.11.0+cu128)** | Section 4, R1-R9 |
| 9 | Partial re-upload (`B5_L4_up1`) looked better than B2 on the core folds (found after the fact, so treated as a hypothesis). Decision rule fixed in advance; fresh-fold test E10 on 2016, 2020, 2022 at 5,000 steps and equal wall-clock | student machine | R10: lead not reproduced; claim withdrawn |
| 10 | Floor, risk-aversion and regime sweeps (E11) | student machine | R11 |
| 11 | FD reference check at gamma = 2, 3, 5, 10 (E12; `p1_fd_floor_check.py`) | sandbox, rerun from this package gives identical numbers | Section 5 [P]; to be repeated on the student machine |
| 12 | Pending | student machine | walk-forward (5 seeds); paired CIs; stress tests; environment manifest; raw-ZIP hash comparison |

## 4. Reproduced on the student machine (independent of the sandbox)

All commands are run from the package root. Seeds as listed; everything is deterministic given library versions (see section 7), except timing.

| ID | Command | Seeds | Key result (mean over seeds) |
|---|---|---|---|
| R1 | `python review3\test_stress_margin.py` | n/a | `OK terminal 0.1998 margin -0.1002 expected -0.1002` (hand-computed case) |
| R2 | `python review3\p1_hjb_validation.py` | n/a (seed 0) | Clipping is the exact constrained maximiser for V_c>0, V_cc<0 (0 of 8,000 suboptimal); fails only for V_c<0, V_cc>0 (22.8%). FD vs analytic cushion-Merton policy in the uncapped region: 2.7e-6 (2006), 5.1e-6 (2013), 0 (2003). FD vs closed forms: 7.8e-5 relative |
| R3 | `python review3\p1_fd_stability_audit.py` and `p1_fd_convergence.py` | n/a | `stable_nt` >= solver guard in every case (1-4% margin); Nt vs 2Nt changes policy by <= 6e-7; mean error converges at about second order (observed order 2.1-2.2); folds with pi_M in [0,1]: default-grid max error <= 1.3e-5; folds with pi_M > 1: transition-zone max error <= 2.2e-5 and overall max 2.6e-3 at the free-boundary kink; 4 fine-grid solves needed Nt raised for stability |
| R4 | `... --preset init --base-year 2006 --seeds 0 1 2 3 4 --workers 2` | 0-4 | Policy RMSE: B2_init 4.94e-6, B2 1.86e-6, B2_noHJB 1.90e-6, B5 1.86e-6, B5_init 3.98e-4. Training time: B2 1.2 s, B5 29.1 s. At the FD floor, so this fold cannot separate models |
| R5 | same, `--base-year 2014` | 0-4 | Policy RMSE: B2_init 1.98e-3, B2 2.42e-3, B2_noHJB 3.46e-3, B5 3.26e-3, B5_init 6.49e-3 |
| R6 | same, `--base-year 2008` | 0-4 | Policy RMSE: B2_init 1.89e-3, B2 2.56e-3, B2_noHJB 2.90e-3, B5 2.99e-3, B5_init 4.09e-3 |
| R7 | `... --preset eqtime --seeds 0 1 2 3 4 --workers 2` | 0-4 | Equal training time (about 30 s): B2_eqtime beats B5 in 10 of 10 fold-seed pairs on policy RMSE (ratio about 3.2x to 8.2x) and HJB residual (about 7.4x to 13.3x). Means (2008, 2014): policy 5.3e-4 / 5.9e-4 vs 3.0e-3 / 3.3e-3; residual 6.2e-4 / 7.5e-4 vs 6.2e-3 / 6.8e-3; upper-boundary error 4.6e-4 / 4.1e-4 vs 4.0e-3 / 5.4e-3 |
| R8 | `... --preset core --seeds 0 1 2 3 4 --workers 2` (base fold 2006) | 0-4 | 19 variants. Nearly all at the FD floor. Exceptions: B5_noHJB 7.2e-5 mean (3 of 5 seeds above floor), B3 1.9e-5 (2 of 5), shallow B5 (L1, L2, 1-layer reupload) slightly worse at 2-3e-6. B1 = B2 and B4 = B5 exactly (raw policy never leaves [0,1] in this fold). B5 residual 5e-15 to 2e-13 in 4 of 5 seeds (4.2e-6 in seed 0), vs 4e-9 to 1e-6 for equal-time B2 (B2_eqtime lower in seed 0 only); policy identical. V_cc clamp never active in any model |
| R9 | `... --preset init --base-year 2014 --seeds 0 1 2 --steps 5000 --workers 2 --out review3\out_5000` and same for 2008 | 0-2 | B2 at 5,000 steps (about 12 s): policy 6.2e-4 (2014), 5.6e-4 (2008), i.e. about 3x better than untrained B2; B2_noHJB stays at 3.8e-3 / 3.1e-3; B5 at 5,000 steps (about 295 s): 8.8e-4 / 9.6e-4, worse than B2 in 6 of 6 fold-seed pairs on policy and on residual |

| R10 | `... --preset followup --base-year Y --steps 5000 --seeds 0 1 2 --workers 2 --out review3\out_followup` for Y = 2016, 2020, 2022 | 0-2 | Paper E10. `B5_L4_up1` vs `B2_eqtime_up1` (B2 given up1's wall-clock): B2 better in 9 of 9 fold-seed pairs. Fold-mean error ratio (up1 / B2) on policy 4.7x (2016), 3.3x (2020), 8.3x (2022); on HJB residual 4.4x, 5.0x, 6.0x. Pre-registered rule (up1 must win on at least 2 of 3 folds) fails; the partial-re-upload lead is withdrawn |
| R11 | `... --preset regimes --seeds 0 1 2 --workers 2 --out review3\out_sweeps`, then `--preset floor gamma --base-year 2014 ...` (500 steps) | 0-2 | Paper E11. No setting favours B5 at equal wall-clock (B5 / B2-at-B5's-time between 4.0x and 9.2x where distinguishable). At gamma = 1.5, B5 is 8% lower than B2 at equal steps (2 of 3 seeds). Uninformative cells (all models at the FD floor or all equal): floor 0.1, gamma 0.5, 5 and 10, fold 2003, interior folds 2002, 2006, 2013. B5 has V_cc >= 0 on 3.7% of evaluation points at gamma = 0.5. The gamma = 2, F = 0.3, fold-2014 configuration is the same computation in all three sweeps and counts once |

Agreement between machines: for R4-R7 the sandbox and student machine give identical policy values to the printed precision for the same seed
(for example 2014 seed 0: B2 0.00238, B5 0.00317), despite different torch versions (2.15.0 vs 2.11.0) and operating systems. Timing differs:
B5 about 29-31 s on the student machine vs about 47 s in the sandbox, so equal-runtime B2 step counts differ (about 12,000 in the sandbox; see
`steps_done` in the student JSONL).

## 5. Sandbox-only findings (not yet reproduced by the student; treat as provisional)

From `review3_evidence.zip` (numpy only; bootstrap seed 20261030):
* Regime split of the 26 folds by the estimated Merton fraction pi_M: 4 below 0, 7 in [0,1], 15 above 1.
* Sharpe is undefined (NaN) in 4 folds (2003, 2004, 2005, 2009) for the FD/B2/B5 policies (they hold cash), so their mean Sharpe averages 22 folds while
  fixed-50% averages 26. On the 22 common folds: FD 0.649, fixed 50% 0.641, market 0.658.
* Paired FD minus fixed-50%: CAGR -1.1 pp, 95% CI [-4.5, +2.2] pp (iid) / [-5.5, +3.2] (3-year block), Wilcoxon p = 0.53; Sharpe +0.008, CI [-0.002, +0.022].
  FD minus market: CAGR -5.2 pp, p = 0.005.
* Floor: even 100% market never breached 0.30 historically (worst year 2008, terminal wealth 0.635); a single-day gap of -70% produced terminal
  breaches in 17% of FD scenarios (22% pathwise); -50% gave 0% terminal and 0.6% pathwise (superseded margin definition).
* 3-seed equal-runtime run (sandbox): B2_eqtime beat B5 in 6 of 6 pairs; boundary ratio range 3.34x to 23.05x.
* FD reference check (paper E12; `provisional/fd_floor_check.json`, rerun with `python review3/p1_fd_floor_check.py`): fold 2014, B2 seed 0, 500 steps. Default (240 x 12,000) vs finest (480 x 32,000) grid, policy RMSE / max: 4.9e-5 / 1.2e-3 (gamma 2), 5.2e-5 / 9.0e-4 (3), 1.9e-4 / 2.7e-4 (5), 5.6e-4 / 7.6e-4 (10). B2 vs finest grid at gamma = 5 and 10: 6.4e-5 and 1.9e-4. So the shared model error at gamma = 5 and 10 is the default grid's smooth bias, not the kink. The paper's draft-2 wording ("consistent with the FD kink") was wrong and is corrected.
* `provisional/` also holds the numpy rerun of the 26-fold baselines (`rerun_fd_baselines.py`), regime/paired-bootstrap/gap-shock evidence (`review3_evidence.py`) and interior FD convergence (`followup_convergence_and_regimes.py`); each takes `<pkg_root> <csv> ...` arguments (see its docstring).
Re-derive all of these with the final scripts (`p1_paired_ci.py`, `p1_stress.py`) once the walk-forward outputs exist.

## 6. Corrections made during the work (so earlier numbers are not mis-cited)

| Issue | Where found | Fix |
|---|---|---|
| `mean_b` in the paired-CI table averaged over all folds of strategy B while the difference used paired folds | audit of v1 | Means and difference now use the same folds; the script asserts `mean_a - mean_b == mean_diff` |
| Pathwise floor margin compared wealth with the floor at a slightly different time than the terminal test, and ignored wealth after trading cost | audit of v1 | Margin now checks (a) after-cost wealth at the start of each day, (b) end-of-day wealth, (c) terminal wealth vs F; verified by `test_stress_margin.py` |
| FD "ground truth" not checked beyond the solver's guard | audit of v1 | `p1_fd_stability_audit.py`; reference moved to a 480 x 32,000 grid; 360 grid is not exact at the free-boundary kink |
| Per-fold print in `p1_fd_convergence.py` was labelled "default" but printed the fine-grid error | student run | Label fixed; CSVs were always correct |
| Statement "B5 is worse than B2 in both cap-binding folds" (equal steps, 500) | cross-check of per-seed data | Wrong for 2008 (B5 lower in 3 of 5 seeds). Correct wording: no consistent policy advantage, higher seed variance |
| Upper-boundary ratio range quoted as 5.8x-22.5x | cross-check | Correct range 3.34x-23.05x (3-seed sandbox run) |
| "Untrained B2 beats trained B2" | cap-binding folds at 500 steps | Holds only at 500 steps; at 5,000 steps trained B2 is about 3x better (R9) |
| Earlier evaluation in the project (`evaluate_model_on_fd_grid`) includes the FD end nodes | code reading | Not changed in the original; `review3` excludes them. Values in old `model_meta_*.json` `numerical_comparison` may be inflated |
| Terminal-condition error | design | Zero by construction (V(c,T) = u(c) is hard-coded); report boundary error instead |

## 7. Software and hardware

Run `python review3/record_environment.py` on each machine and keep `review3/out/environment_manifest.json` with the results. It records Python/OS,
library versions, CPU count, dataset hash, and SHA-256 of every source file and result file.

| | Student machine | Sandbox |
|---|---|---|
| OS / Python | Windows, Python 3.11 | Linux, Python 3.13 |
| torch / numpy | 2.11.0+cu128 / 2.4.6 | 2.15.0+cu132 (CPU) / 2.5.3 |
| pandas / scipy | 3.1.0 / 1.17.1 | 3.0.5 / 1.18.1 |
| CPU | to be recorded (manifest) | 2 logical cores |

Notes: workers run with 1 torch thread each when `--workers 2`, so absolute timings include some contention (B5 and its matched B2 are timed in
the same process, so the comparison is fair, but quote times as approximate). Do not run other heavy work during timing experiments.

## 8. Claim ledger

| Claim | Evidence | Status |
|---|---|---|
| Clipping the vertex solves the constrained maximisation when V_c>0, V_cc<0 | R2 | Reproduced (student) |
| Trained networks satisfy V_cc < 0 on the evaluation grid | R4-R9 (`frac_Vcc_nonneg` = 0); **not true for B5 at gamma = 0.5 (3.7% of points, R11)** | Reproduced for the main settings; exception recorded |
| FD reference is converged in the mean; max error near the free boundary is about 1e-3 | R3 | Reproduced |
| Policy accuracy in interior folds is limited by the FD discretisation floor (about 1.85e-6), not by the model | R4, R8 | Reproduced |
| In cap-binding folds, at 500 steps B2_init is not worse than trained B2 on policy RMSE | R5, R6 (5 seeds each) | Reproduced; **500-step artefact** |
| With 5,000 steps trained B2 is about 3x better than untrained, and the HJB loss is essential | R9 (3 seeds, 2 folds) | Reproduced; small sample |
| Equal training wall-clock: B2 beats B5 on policy RMSE and HJB residual in cap-binding folds | R7 (10 of 10 pairs) | Reproduced; 2 folds |
| B5 reaches near-zero residual in the interior fold (4 of 5 seeds) while policy is unchanged | R8 | Reproduced; fold 2006 only |
| Depth / reuploading / entangler / boundary-loss ablations | `out/ablation_summary.csv` (folds 2006, 2014, 2008; 5 seeds) | Reproduced; fold 2006 is at the floor, so conclusions rest on 2014 and 2008 |
| Penalty vs constraint-consistent training (B1/B4 vs B2/B5) | identical in 2006; in cap-binding folds policy RMSE 1.9e-2 / 2.7e-2 (2008) and 3.2e-2 / 5.1e-2 (2014) vs 2.6e-3 / 3.0e-3 and 2.4e-3 / 3.3e-3 for B2 / B5 | Reproduced (5 seeds, 2 folds) |
| Partial re-upload (`B5_L4_up1`) beats B2 | core folds suggested it; R10 on 3 fresh folds: B2 wins 9 of 9 at equal wall-clock | **Not confirmed; withdrawn** |
| No tested gamma, floor or regime favours B5 at equal wall-clock | R11 (fold 2014 for gamma and floor; six regime folds) | Reproduced; 3 seeds, 500 steps; one market fold per sweep |
| Shared model error at gamma = 5 and 10 is the default FD grid's smooth bias | FD floor check (E12) | **Provisional [P]** until `p1_fd_floor_check.py` is run on the student machine |
| Paired CIs, Sharpe-NaN correction, stress/gap-shock floor results | sandbox only | **Provisional** until the walk-forward results exist |
| Equal-parameter and equal-runtime comparison on historical outcomes | not run | Pending (walk-forward, 5 seeds) |
| B5 is classically simulated; wall-clock disadvantage reflects simulation cost, not hardware | by construction | No quantum-advantage claim is supported |

## 9. What remains and the order to do it

1. Walk-forward with seeds 0-4 (`python historical/walk_forward_backtest.py --seeds 0 1 2 3 4 --methods B2 B5`); keep `walk_forward_fold_results.csv` and the `model_*.pt` files in `historical/results/`. Add a 5,000-step B2 sensitivity run if feasible.
2. `python review3/p1_paired_ci.py --fold-csv historical/results/walk_forward_fold_results.csv`, then `python review3/p1_stress.py --results-dir historical/results --methods B2 B5 --seed 0`; replace the [P] numbers in the paper.
3. `python review3/p1_fd_floor_check.py` on the student machine (replaces the [P] FD check).
4. `python review3/record_environment.py`; compare the SHA-256 of the retained raw French ZIP with the value quoted in the paper (see Section 1).
5. Read Wang et al. (arXiv:2604.03346) in the PDF and verify the comparison table in paper Section 2.2, which was built from an extraction.
6. Optional: widen or remove the S-window (trial-form dependence), a finer-grid reference for gamma >= 5.
7. Archive: this package, the retained French ZIP and both manifests. Quote `steps_done` (not `steps`) and the numbers of seeds and folds next to every statistic.

## 10. Known limitations to state in the paper

* Single risky asset and a single data source; annual reset episodes; constant-parameter model with rolling estimates.
* The ablation and equal-runtime evidence covers a few selected folds (2006 interior; 2008 and 2014 cap-binding; E10 adds 2016, 2020, 2022 for one variant; E11 adds six regime folds at 500 steps and 3 seeds) and 3-5 seeds, so it is descriptive,
  not a statistical test across regimes. Nine distinct market folds in all; sweeps over gamma or floor on fold 2014 are one market fold.
* The 500-step budget used in the original walk-forward under-trains both models in cap-binding regimes (R5-R9); consider a 5,000-step sensitivity run for B2.
* The pi <= 1 constraint is a no-leverage cap, not a gap-risk constraint; severe single-day gaps can breach the floor. A -70% day is far outside the 1926-2026 sample.
* Block-bootstrap intervals over 26 overlapping-window folds are a sensitivity analysis; serial dependence is not fully removed.
