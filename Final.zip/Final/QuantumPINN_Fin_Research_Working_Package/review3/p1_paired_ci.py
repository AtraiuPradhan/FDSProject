"""P1: paired confidence intervals for historical strategy comparisons.

Input: walk_forward_fold_results.csv produced by historical/walk_forward_backtest.py (one row per strategy x held-out year;
B2/B5 rows are named B2_seed0 ... and are averaged over seeds within each fold before pairing).

Why fold-level pairing: the 26 annual episodes are the unit of replication. Seeds only measure training noise.
Metrics: cagr, excess_cagr (= cagr minus the cash strategy's CAGR in the same fold; always defined), sharpe_vs_rf,
max_drawdown, annualized_volatility. Sharpe is undefined (NaN) in folds where a policy is entirely in cash, so
Sharpe comparisons use only folds where BOTH strategies have a value, and the number of such folds is reported (n).
Tests: iid bootstrap CI, moving-block bootstrap CI (block = 3 years, for serial dependence in market regimes), Wilcoxon signed-rank,
Holm correction within each metric.
Run: python review3/p1_paired_ci.py --fold-csv historical/results/walk_forward_fold_results.csv
"""
from __future__ import annotations

import argparse
import itertools
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from r3_common import OUT_DEFAULT, bootstrap_ci

METRICS = ["cagr", "excess_cagr", "sharpe_vs_rf", "max_drawdown", "annualized_volatility"]
DEFAULT_PAIRS = [("B2", "fd_reference"), ("B5", "fd_reference"), ("B5", "B2"),
                 ("B2", "fixed_50"), ("B5", "fixed_50"), ("fd_reference", "fixed_50"),
                 ("B2", "market_100"), ("B5", "market_100"), ("fd_reference", "market_100"),
                 ("B2", "constant_merton_no_floor"), ("B5", "constant_merton_no_floor")]


LIMITS = """LIMITATIONS to state with these results:
  - Unit of analysis = 26 annual folds. Consecutive folds share 4 of 5 training years, so estimated parameters (and therefore policies)
    are serially dependent; the iid bootstrap and Wilcoxon test assume independent differences. The 3-year moving-block bootstrap is a
    SENSITIVITY analysis, not a correction that removes the dependence (see lag1_autocorr_of_diff; n=26 is small for block methods).
  - Holm correction is applied within each metric across the listed pairs only; other comparisons are exploratory.
  - Sharpe pairs use only folds where both strategies have a defined Sharpe (n_folds shows how many)."""


def holm(p):
    p = np.asarray(p, float); order = np.argsort(p); m = len(p); adj = np.empty(m); run = 0.0
    for rank, i in enumerate(order):
        run = max(run, (m - rank) * p[i]); adj[i] = min(run, 1.0)
    return adj


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fold-csv", required=True); ap.add_argument("--out", default=str(OUT_DEFAULT))
    ap.add_argument("--block", type=int, default=3); ap.add_argument("--nboot", type=int, default=20000)
    ap.add_argument("--seed", type=int, default=2026)
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    f = pd.read_csv(a.fold_csv)
    cash = f[f.strategy == "cash_0"].set_index("test_year")["cagr"]
    f["excess_cagr"] = f["cagr"] - f["test_year"].map(cash)
    f["group"] = f["strategy"].str.replace(r"_seed\d+$", "", regex=True)
    g = f.groupby(["test_year", "group"])[METRICS].mean().reset_index()      # average over seeds inside each fold
    wide = {m: g.pivot(index="test_year", columns="group", values=m) for m in METRICS}
    present = set(g.group)
    pairs = [(x, y) for x, y in DEFAULT_PAIRS if x in present and y in present]
    rng = np.random.default_rng(a.seed)
    rows = []
    for (x, y), m in itertools.product(pairs, METRICS):
        pair = pd.concat([wide[m][x], wide[m][y]], axis=1, keys=["a", "b"]).dropna()   # SAME folds for means and difference
        d = (pair["a"] - pair["b"]).to_numpy()
        if len(d) < 3:
            continue
        iid = bootstrap_ci(d, rng, a.nboot, 1); blk = bootstrap_ci(d, rng, a.nboot, a.block)
        try:
            pw = float(stats.wilcoxon(d).pvalue) if np.any(d != 0) else 1.0
        except ValueError:
            pw = 1.0
        ac1 = float(np.corrcoef(d[:-1], d[1:])[0, 1]) if len(d) > 3 and np.std(d) > 0 else float("nan")
        rows.append(dict(a=x, b=y, metric=m, n_folds=len(d), folds_excluded=int(len(wide[m]) - len(d)),
                         mean_a=float(pair["a"].mean()), mean_b=float(pair["b"].mean()), mean_diff_a_minus_b=float(d.mean()),
                         ci95_iid_lo=iid[0], ci95_iid_hi=iid[1], ci95_block_lo=blk[0], ci95_block_hi=blk[1],
                         wilcoxon_p=pw, frac_folds_a_higher=float((d > 0).mean()), lag1_autocorr_of_diff=ac1))
    res = pd.DataFrame(rows)
    res["wilcoxon_p_holm"] = res.groupby("metric")["wilcoxon_p"].transform(lambda s: holm(s.values))
    res["ci_excludes_zero_block"] = (res.ci95_block_lo > 0) | (res.ci95_block_hi < 0)
    res["check_mean_a_minus_b_equals_diff"] = np.isclose(res.mean_a - res.mean_b, res.mean_diff_a_minus_b, atol=1e-12)
    assert res["check_mean_a_minus_b_equals_diff"].all(), "means and paired difference use different samples"
    res.to_csv(out / "paired_strategy_comparisons.csv", index=False)
    with pd.option_context("display.width", 220, "display.max_rows", 500, "display.float_format", "{:.4g}".format):
        print(res[["a", "b", "metric", "n_folds", "mean_diff_a_minus_b", "ci95_block_lo", "ci95_block_hi", "wilcoxon_p_holm"]].to_string(index=False))
    print(LIMITS)
    print(f"\nWrote {out/'paired_strategy_comparisons.csv'}")


if __name__ == "__main__":
    main()
