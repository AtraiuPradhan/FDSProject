"""P1: validate the HJB policy derivation and the constrained (clipped) solution.

Checks
  1. Hamiltonian maximiser: for H(pi) = (mu-r) w pi V_c + 0.5 sigma^2 w^2 pi^2 V_cc on pi in [0,1], compare the brute-force
     maximum with the code's policy (hjb.policy_clip, incl. its V_cc <= -eps clamp), split by the signs of V_c and V_cc.
     Expectation: exact whenever V_c > 0 and V_cc < 0 (strictly concave quadratic => clip of the vertex is the constrained argmax).
     Other sign regions show exactly where the "clip" shortcut is NOT a valid constrained maximiser.
  2. FD solver vs closed forms: cap off (F>0) reproduces V = u(c) exp(S_unc (T-t)); F=0 with cap reproduces the P0 closed form.
  3. FD constrained solution vs the analytic cushion-Merton policy pi = clip(pi_M) * c / w in the region where the cap is inactive,
     for one fold from each regime (pi_M < 0, 0..1, > 1). Deviations are confined to the free-boundary neighbourhood.
Run:  python review3/p1_hjb_validation.py [--data PATH]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from r3_common import OUT_DEFAULT, fold_params, load_data, solve_fd_stable
from qpinn_fin.config import PRIMARY
from qpinn_fin.hjb import policy_clip
from qpinn_fin.reference import p0_closed_form, solve_fd

ASSUMPTIONS = """Assumptions behind  pi*(c,t) = clip( -(mu-r) V_c / (sigma^2 w V_cc), 0, 1 ),  w = c + F exp(-r(T-t)):
  A1  constant mu, r, sigma, gamma on the horizon (rolling estimates only approximate this);
  A2  the floor is riskless-replicable: F exp(-r(T-t)) is the PV of the floor at the constant r, and w > floor, i.e. c > 0;
  A3  V_c > 0 and V_cc < 0 (strict concavity in the cushion): then H(pi) is a strictly concave quadratic, its unconstrained vertex is
      the raw policy, and the maximiser over [0,1] is the projection (clip) of the vertex -- exact, pointwise in (c,t);
  A4  the constraint pi in [0,1] is no-short / no-leverage on TOTAL wealth (A <= w); it is not a gap-risk or drawdown constraint;
  A5  the network must satisfy A3 -- it is not enforced by construction (policy_raw clamps V_cc <= -eps), so report
      frac_Vcc_nonneg / frac_Vc_nonpos from p1_ablation.py for every trained model."""


def check_maximiser(n=400000, seed=0):
    rng = np.random.default_rng(seed)
    p = PRIMARY
    V_c = rng.choice([-1, 1], n) * np.exp(rng.uniform(-3, 2, n))
    V_cc = rng.choice([-1, 1], n) * np.exp(rng.uniform(-3, 2, n))
    c = np.exp(rng.uniform(np.log(0.1), np.log(5), n)); t = rng.uniform(0, 1, n)
    w = c + p.F * np.exp(-p.r * (p.T - t))
    a = p.mu - p.r
    code = policy_clip(torch.tensor(V_c), torch.tensor(V_cc), torch.tensor(c), torch.tensor(t), p).numpy()
    grid = np.linspace(0, 1, 2001)
    sub = rng.choice(n, 60000, replace=False)
    out = {}
    for name, m in {"Vc>0,Vcc<0 (assumed)": (V_c > 0) & (V_cc < 0), "Vc>0,Vcc>0": (V_c > 0) & (V_cc > 0),
                    "Vc<0,Vcc<0": (V_c < 0) & (V_cc < 0), "Vc<0,Vcc>0": (V_c < 0) & (V_cc > 0)}.items():
        idx = sub[m[sub]][:8000]
        H = lambda pi: a * w[idx, None] * pi[None, :] * V_c[idx, None] + 0.5 * p.sigma ** 2 * w[idx, None] ** 2 * pi[None, :] ** 2 * V_cc[idx, None]
        best = H(grid).max(axis=1)
        got = (a * w[idx] * code[idx] * V_c[idx] + 0.5 * p.sigma ** 2 * w[idx] ** 2 * code[idx] ** 2 * V_cc[idx])
        gap = best - got
        scale = np.maximum(np.abs(best), 1e-12)
        out[name] = dict(n=int(len(idx)), frac_suboptimal=float(np.mean(gap > 1e-6 * scale + 1e-12)),
                         max_rel_objective_gap=float(np.max(gap / scale)))
    return out


def check_fd_closed_forms():
    res = {}
    p = PRIMARY
    sol = solve_fd(p, cap=False, Nx=240, Nt=12000, n_save=20)
    c = np.geomspace(0.5, 4, 40); errs = []
    for i, t in enumerate(sol.t):
        V, _ = sol.interp(i, c)
        Vr = c ** (1 - p.gamma) / (1 - p.gamma) * np.exp(p.s_unc * (p.T - t))
        errs.append(np.max(np.abs((V - Vr) / np.abs(Vr))))
    res["F>0, cap off: max rel. V error vs closed form (c in [0.5,4])"] = float(np.max(errs))
    p0 = p.with_floor(0.0)
    sol0 = solve_fd(p0, cap=True, Nx=240, Nt=12000, n_save=20)
    errs, perr = [], []
    for i, t in enumerate(sol0.t[:-1]):
        V, pi = sol0.interp(i, c)
        Vr, pir = p0_closed_form(c, t, p0)
        errs.append(np.max(np.abs((V - Vr) / np.abs(Vr)))); perr.append(np.max(np.abs(pi - pir)))
    res["F=0, cap on: max rel. V error vs P0 closed form"] = float(np.max(errs))
    res["F=0, cap on: max |pi - clip(pi_M,0,1)|"] = float(np.max(perr))
    return res


def check_cushion_merton(df):
    out = {}
    for year, regime in ((2003, "pi_M<0"), (2006, "0<=pi_M<=1"), (2008, "pi_M>1"), (2013, "0<=pi_M<=1")):
        p = fold_params(df, year)
        sol = solve_fd_stable(p)
        c = np.geomspace(0.15, 3.0, 120)
        dev, n = 0.0, 0
        for i, t in enumerate(sol.t[:-1]):
            w = c + p.F * np.exp(-p.r * (p.T - t))
            _, pi_fd = sol.interp(i, c)
            analytic = np.clip(max(p.merton_fraction, 0.0) * c / w, 0, 1)
            free = (pi_fd < 0.98) & (analytic < 0.98)           # region where the cap is inactive
            if free.any():
                dev = max(dev, float(np.max(np.abs(pi_fd[free] - analytic[free])))); n += int(free.sum())
        out[f"{year} ({regime}, pi_M={p.merton_fraction:.3f})"] = dict(points_in_uncapped_region=n, max_abs_dev_from_cushion_merton=dev)
    return out


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default=None); ap.add_argument("--out", default=str(OUT_DEFAULT))
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    df = load_data(a.data)
    res = {"assumptions": ASSUMPTIONS, "maximiser_check": check_maximiser(), "fd_vs_closed_form": check_fd_closed_forms(),
           "fd_vs_cushion_merton_uncapped_region": check_cushion_merton(df)}
    (out / "hjb_validation.json").write_text(json.dumps(res, indent=2))
    print(ASSUMPTIONS); print(json.dumps({k: v for k, v in res.items() if k != "assumptions"}, indent=2))


if __name__ == "__main__":
    main()
