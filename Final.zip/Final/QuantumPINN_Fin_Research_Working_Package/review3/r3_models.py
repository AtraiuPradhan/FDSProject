"""Model variants needed for the ablations (the original models.py is left untouched)."""
from __future__ import annotations

import torch

from qpinn_fin.models import MLPS, QuantumS, _ry, _rz, apply_1q


class QuantumSReupload(QuantumS):
    """Same circuit as B5, but data are re-uploaded only in the first `n_upload` layers.

    n_upload == layers reproduces B5 exactly (same parameters, same forward pass).
    Trainable-layer count and re-upload count are therefore separable: depth vs. re-uploading.
    """

    def __init__(self, p, exps, n_qubits=4, layers=4, n_upload=None, entangler="ring"):
        super().__init__(p, exps, n_qubits, layers, entangler)
        self.n_upload = layers if n_upload is None else int(n_upload)
        if not 1 <= self.n_upload <= layers:
            raise ValueError("n_upload must be in [1, layers]")

    def raw(self, xn, tn):
        B, n = xn.shape[0], self.n
        state = torch.zeros(B, 2 ** n, dtype=torch.complex128, device=xn.device)
        state[:, 0] = 1.0
        for l in range(self.L):
            if l < self.n_upload:
                for q in range(n):
                    f = xn if q % 2 == 0 else tn
                    state = apply_1q(state, _ry(self.base * self.mult[q] * f), q, n)
            for q in range(n):
                th = self.theta[l, q]
                state = apply_1q(state, _rz(th[0]) @ _ry(th[1]) @ _rz(th[2]), q, n)
            if self.pairs:
                state = state * self.sign
        probs = state.real ** 2 + state.imag ** 2
        return (probs @ self.Z) @ self.readout + self.bias


def mlp_matching(p, exps, n_target: int, depths=(1, 2, 3)) -> MLPS:
    """MLP (uniform width, `depth` hidden layers) whose parameter count is closest to n_target."""
    best = None
    for depth in depths:
        for h in range(2, 96):
            m = MLPS(p, exps, hidden=h, layers=depth)
            key = (abs(m.n_params() - n_target), depth)
            if best is None or key < best[0]:
                best = (key, h, depth)
    return MLPS(p, exps, hidden=best[1], layers=best[2])
