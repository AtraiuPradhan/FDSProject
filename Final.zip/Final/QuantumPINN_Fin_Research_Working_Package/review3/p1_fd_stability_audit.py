"""Audit of the FD reference used as 'ground truth'.

1. The stability guard in reference.solve_fd (dt <= 0.9 dx^2 / (q_max^2 sigma^2), q_max = 1 + F/cmin) is the ONLY check; it is a
   sufficient condition for the diffusion term only. Here: (a) stable_nt() is compared with the guard's exact threshold, (b) results
   are tested for time-step independence (Nt vs 2 Nt at fixed Nx), (c) space refinement is run on 120/240/480 with Nt scaled ~Nx^2
   and the observed order and the 'fine' (360) vs 'finest' (480) distance are reported, per regime, interior vs kink region.
2. Output: fd_stability_audit.csv. If fine-vs-finest is not clearly below default-vs-fine, 'fine' is not a safe ground truth.
Run: python review3/p1_fd_stability_audit.py [--years 2002 2006 2008 2014]
"""
import argparse
import numpy as np
import pandas as pd
from r3_common import OUT_DEFAULT, fold_params, load_data, regime_of, stable_nt
from qpinn_fin.reference import solve_fd

cg = np.geomspace(0.1, 4.0, 300)
def field(s): return np.clip(np.array([np.interp(np.log(cg), s.x, s.pi[i]) for i in range(len(s.t))]), 0, 1)
def valid_nt(p, nx, nt):
    try:
        solve_fd(p, cap=True, Nx=nx, Nt=nt, n_save=40); return True
    except ValueError:
        return False

ap = argparse.ArgumentParser(); ap.add_argument("--data", default=None); ap.add_argument("--out", default=str(OUT_DEFAULT))
ap.add_argument("--years", nargs="+", type=int, default=[2002, 2006, 2008, 2014, 2018, 2022])
a = ap.parse_args()
from pathlib import Path
out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
df = load_data(a.data); rows = []
for y in a.years:
    p = fold_params(df, y)
    # (a) guard threshold: smallest Nt (multiple of 40) accepted by the solver vs stable_nt()
    for nx in (120, 240, 360):
        lo = 40
        while not valid_nt(p, nx, lo) and lo < 400000: lo += 40 * max(1, lo // 4000)
        # refine downward in steps of 40
        while lo > 40 and valid_nt(p, nx, lo - 40): lo -= 40
        rows.append(dict(year=y, check="guard_threshold", nx=nx, solver_min_nt=lo, stable_nt=stable_nt(p, nx, 40), ok=stable_nt(p, nx, 40) >= lo))
    ref = {}
    for nx, nt0 in ((120, 6000), (240, 12000), (360, 18000), (480, 32000)):
        ref[nx] = solve_fd(p, cap=True, Nx=nx, Nt=stable_nt(p, nx, nt0), n_save=40)
    f = {nx: field(s) for nx, s in ref.items()}
    zone = (f[480] > 0.02) & (f[480] < 0.98)
    def d(a_, b_):
        e = np.abs(f[a_] - f[b_]); return e.mean(), e.max(), (e[zone].max() if zone.any() else np.nan), (e[~zone].max() if (~zone).any() else np.nan)
    for a_, b_ in ((120, 240), (240, 360), (240, 480), (360, 480)):
        m, mx, mz, ms = d(a_, b_)
        rows.append(dict(year=y, regime=regime_of(p.merton_fraction), check=f"Nx{a_}_vs_Nx{b_}", mae=m, max_all=mx, max_transition=mz, max_saturated=ms))
    # (b) time-step independence at Nx=240
    s1 = solve_fd(p, cap=True, Nx=240, Nt=stable_nt(p, 240, 12000), n_save=40)
    s2 = solve_fd(p, cap=True, Nx=240, Nt=2 * stable_nt(p, 240, 12000), n_save=40)
    e = np.abs(field(s1) - field(s2))
    rows.append(dict(year=y, regime=regime_of(p.merton_fraction), check="Nt_vs_2Nt_at_Nx240", mae=e.mean(), max_all=e.max()))
    print(y, "done", flush=True)
r = pd.DataFrame(rows); r.to_csv(out / "fd_stability_audit.csv", index=False)
with pd.option_context("display.width", 220, "display.max_rows", 500, "display.float_format", "{:.3g}".format):
    print(r.to_string(index=False))
