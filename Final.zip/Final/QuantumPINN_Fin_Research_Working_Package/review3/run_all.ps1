# run from the package root:  powershell -ExecutionPolicy Bypass -File review3\run_all.ps1   (steps 1-9 of review3\README.md, then 11 if walk-forward results exist)
$ErrorActionPreference = "Stop"
function Run { & python @args; if ($LASTEXITCODE -ne 0) { throw "failed: python $args" } }
Run review3\check_setup.py
Run review3\test_stress_margin.py
Run review3\p1_hjb_validation.py
Run review3\p1_fd_stability_audit.py
Run review3\p1_fd_convergence.py
foreach ($y in 2006,2014,2008) { Run review3\p1_ablation.py --preset init --base-year $y --seeds 0 1 2 3 4 --workers 2 }
Write-Host "Inspect the init results (review3\out\ablation_summary.csv) before continuing; Ctrl-C to stop"; Start-Sleep 20
Run review3\p1_ablation.py --preset eqtime --seeds 0 1 2 3 4 --workers 2
foreach ($y in 2006,2014,2008) { Run review3\p1_ablation.py --preset core --base-year $y --seeds 0 1 2 3 4 --workers 2 }
foreach ($y in 2014,2008) { Run review3\p1_ablation.py --preset init --base-year $y --seeds 0 1 2 --steps 5000 --workers 2 --out review3\out_5000 }
foreach ($y in 2016,2020,2022) { Run review3\p1_ablation.py --preset followup --base-year $y --steps 5000 --seeds 0 1 2 --workers 2 --out review3\out_followup }
Run review3\p1_ablation.py --preset regimes --seeds 0 1 2 --workers 2 --out review3\out_sweeps
Run review3\p1_ablation.py --preset floor gamma --base-year 2014 --seeds 0 1 2 --workers 2 --out review3\out_sweeps
Run review3\p1_fd_floor_check.py
if (Test-Path historical\results\walk_forward_fold_results.csv) {
  Run review3\p1_paired_ci.py --fold-csv historical\results\walk_forward_fold_results.csv
  Run review3\p1_stress.py --results-dir historical\results --methods B2 B5 --seed 0
} else { Write-Host "Skipping paired CIs and stress test: run the walk-forward first (review3\README.md step 10)" }
Run review3\record_environment.py
