"""Verifies the package root has what the review3 scripts need. Run first:  python review3/check_setup.py"""
from pathlib import Path
import importlib
root = Path(__file__).resolve().parent.parent
need = {"implementation/qpinn_fin/qpinn_fin/reference.py": "FD solver", "implementation/qpinn_fin/qpinn_fin/models.py": "models",
        "historical/walk_forward_backtest.py": "backtest", "historical/data/french_daily_market_rf.csv": "data CSV"}
opt = {"historical/results/walk_forward_fold_results.csv": "needed by p1_paired_ci.py",
       "historical/results/model_2006_B2_seed0.pt": "needed by p1_stress.py for B2/B5 (else use --methods none)"}
ok = True
for f, why in need.items():
    e = (root / f).exists(); ok &= e; print(("OK      " if e else "MISSING ") + f + f"  ({why})")
for f, why in opt.items():
    print(("OK      " if (root / f).exists() else "missing ") + f + f"  ({why})")
for m in ("torch", "numpy", "pandas", "scipy"):
    try: importlib.import_module(m); print("OK      import", m)
    except ImportError: ok = False; print("MISSING python package", m)
print("\nREADY" if ok else "\nFix the MISSING items above before running anything.")
