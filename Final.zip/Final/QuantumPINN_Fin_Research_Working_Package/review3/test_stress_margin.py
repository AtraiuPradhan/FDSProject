"""Hand-computed check of p1_stress.run_one: one -80% gap on day 100, market_100, flat other days."""
import numpy as np, pandas as pd
from r3_common import wfb, Params
import p1_stress

n = 250
te = pd.DataFrame({"date": pd.bdate_range("2010-01-04", periods=n), "market_total": 0.0, "rf": 1e-4, "mkt_rf": -1e-4})
te.loc[100, ["market_total", "mkt_rf"]] = [-0.8, -0.8 - 1e-4]
p = Params(mu=0.1, r=0.03, sigma=0.15, gamma=2.0, T=1.0, F=0.30, cmin=0.05, cmax=5.0)
tw, mg = p1_stress.run_one(te, p, "market_100", None)
w_after_cost = 1.0 * (1 - 10 / 1e4)                       # day-0 trade 0 -> 1 costs 10 bp
w_end100 = w_after_cost * (1 - 0.8)
floor_end100 = 0.30 * np.exp(-0.03 * (1 - 101 / 252))
expected_candidates = [w_end100 - floor_end100, w_after_cost - 0.30 * np.exp(-0.03), w_after_cost * (1 - 0.8) - 0.30]
# terminal wealth stays at w_end100 (flat afterwards, no more rebalancing cost because weight stays 1)
assert abs(tw - w_end100) < 5e-4, (tw, w_end100)          # small drift from the weight-rebalancing of later 21-day dates
exp_margin = min(expected_candidates)
assert abs(mg - exp_margin) < 5e-4, (mg, exp_margin)
print("OK  terminal", round(tw, 5), "margin", round(mg, 5), "expected", round(exp_margin, 5))
# terminal-vs-pathwise consistency: pathwise margin <= terminal margin always
assert mg <= tw - p.F + 1e-12
