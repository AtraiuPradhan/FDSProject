"""Evidence for Review-3 items, numpy-only. Usage: python review3_evidence.py <pkg_root> <csv> <fold_csv> <out_dir>"""
import sys, types, json
from pathlib import Path
import numpy as np
import pandas as pd

pkg_root, csv_path, fold_csv, out_dir = map(Path, sys.argv[1:5])
sys.path.insert(0, str(pkg_root / "implementation" / "qpinn_fin"))
from qpinn_fin.config import Params          # noqa: E402
from qpinn_fin.reference import solve_fd     # noqa: E402

src = (pkg_root / "historical" / "walk_forward_backtest.py").read_text()
for bad in ["import torch\n", "from qpinn_fin.trainer import train\n", "from qpinn_fin.hjb import derivs, policy_raw\n"]:
    src = src.replace(bad, "")
mod = types.ModuleType("wfb"); mod.__dict__["__file__"] = str(pkg_root / "historical" / "walk_forward_backtest.py")
exec(compile(src, "wfb", "exec"), mod.__dict__)
out_dir.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(20261030)

df = pd.read_csv(csv_path, parse_dates=["date"]).sort_values("date").dropna().reset_index(drop=True)
fold = pd.read_csv(fold_csv)
res = {}

# ---------------------------------------------------------------- A. clipping == constrained maximiser
# H(pi) = a w pi Vc + 0.5 s^2 w^2 pi^2 Vcc. For Vc>0, Vcc<0 it is a strictly concave quadratic in pi.
bad, n = 0, 200000
Vc = rng.uniform(0.01, 5, n); Vcc = -rng.uniform(0.01, 5, n); w = rng.uniform(0.3, 6, n)
a = rng.uniform(0.0, 0.2, n); s = rng.uniform(0.05, 0.5, n)
raw = -a * Vc / (s**2 * w * Vcc)
grid = np.linspace(0, 1, 1001)
idx = rng.choice(n, 4000, replace=False)
for i in idx:
    H = a[i] * w[i] * grid * Vc[i] + 0.5 * s[i]**2 * w[i]**2 * grid**2 * Vcc[i]
    if abs(grid[np.argmax(H)] - np.clip(raw[i], 0, 1)) > 1.1e-3:
        bad += 1
res["clip_equals_constrained_argmax_mismatches_of_4000"] = bad

# ---------------------------------------------------------------- B. regimes and floor vacuity
f = fold.copy()
piM = f[f.strategy == "fd_reference"].set_index("test_year")["pi_M"]
res["regime_counts"] = {"piM_lt_0": int((piM < 0).sum()), "piM_0_1": int(((piM >= 0) & (piM <= 1)).sum()),
                        "piM_gt_1": int((piM > 1).sum())}
tw = f.pivot(index="test_year", columns="strategy", values="terminal_wealth")
res["min_terminal_wealth"] = {k: float(tw[k].min()) for k in tw.columns}
res["worst_year_market100"] = int(tw["market_100"].idxmin())
res["floor_F"] = 0.30
# smallest floor level at which each strategy would have breached at least once historically
res["min_terminal_wealth_is_floor_that_first_binds"] = "any F above these values breaches in the worst year"

# ---------------------------------------------------------------- C. paired bootstrap / tests (fold level)
def paired(a_name, b_name, col, nboot=20000, block=3):
    d = (f[f.strategy == a_name].set_index("test_year")[col] - f[f.strategy == b_name].set_index("test_year")[col]).dropna()
    x = d.to_numpy(); n = len(x)
    if n == 0:
        return None
    iid = np.array([x[rng.integers(0, n, n)].mean() for _ in range(nboot)])
    nb = int(np.ceil(n / block)); mb = []
    for _ in range(nboot):
        st = rng.integers(0, n - block + 1, nb)
        mb.append(np.concatenate([x[s0:s0 + block] for s0 in st])[:n].mean())
    mb = np.array(mb)
    from scipy import stats
    return {"mean_diff": float(x.mean()), "iid_ci95": [float(np.percentile(iid, 2.5)), float(np.percentile(iid, 97.5))],
            "block3_ci95": [float(np.percentile(mb, 2.5)), float(np.percentile(mb, 97.5))],
            "wilcoxon_p": float(stats.wilcoxon(x).pvalue) if np.any(x != 0) else 1.0,
            "frac_folds_a_better": float((x > 0).mean())}

res["paired"] = {}
for b in ["fixed_50", "market_100", "constant_merton_no_floor", "cash_0"]:
    for col in ["cagr", "sharpe_vs_rf", "max_drawdown", "annualized_volatility"]:
        res["paired"][f"fd_minus_{b}__{col}"] = paired("fd_reference", b, col)

# ---------------------------------------------------------------- D. shocks + pathwise floor
def folds_iter():
    for year in range(2000, 2026):
        tr = df[(df.date >= pd.Timestamp(year - 5, 1, 1)) & (df.date < pd.Timestamp(year, 1, 1))]
        te = df[(df.date >= pd.Timestamp(year, 1, 1)) & (df.date < pd.Timestamp(year + 1, 1, 1))].reset_index(drop=True)
        yield year, tr, te, mod.estimate_params(tr, 2.0, 0.30, 0.05, 5.0)

def path_margin(rows, p):
    # wealth_end vs discounted floor at end of that day (continuous floor path)
    m = []
    for r in rows:
        t_end = r["time_years"] + 1 / 252
        m.append(r["wealth_end"] - p.F * np.exp(-p.r * (p.T - t_end)))
    return float(np.min(m))

def run(te, p, strat, policy):
    met = mod.simulate(te, p, strat, policy, 21, 10 / 1e4, save_path=True)
    rows = met.pop("allocation_path")
    return met["terminal_wealth"], path_margin(rows, p)

shock_sizes = [-0.10, -0.20, -0.30, -0.50, -0.70]
days = list(range(5, 245, 20))
agg = {}   # (scenario, strategy) -> list of (terminal, pathmargin)
F_CHECK = [0.30, 0.60, 0.80, 0.90]
agg_F = {}
spike_rows = []
for year, tr, te, p in folds_iter():
    sol = solve_fd(p, cap=True, Nx=240, Nt=12000, n_save=40)
    pol_fd = lambda c, t, sol=sol: mod.fd_policy(sol, c, t)
    # misspecified model: drift +10pp and vol halved -> aggressive policy from wrong parameters
    pm = Params(mu=p.mu + 0.10, r=p.r, sigma=max(p.sigma * 0.5, 0.03), gamma=p.gamma, T=1.0, F=p.F, cmin=p.cmin, cmax=p.cmax)
    solm = solve_fd(pm, cap=True, Nx=240, Nt=12000, n_save=40)
    pol_m = lambda c, t, sol=solm: mod.fd_policy(sol, c, t)
    for x in shock_sizes:
        for d in days:
            te2 = te.copy()
            te2.loc[d, "market_total"] = x
            te2.loc[d, "mkt_rf"] = x - te2.loc[d, "rf"]
            for name, pol, strat in [("fd", pol_fd, "fd_reference"), ("fd_misspec", pol_m, "fd_reference"),
                                     ("fixed_50", None, "fixed_50"), ("market_100", None, "market_100")]:
                tw_, pm_ = run(te2, p, strat, pol)
                agg.setdefault((x, name), []).append((tw_, pm_))
    # vol spike: demeaned returns x3 over a random 40-day window, once per fold
    te3 = te.copy(); st = int(rng.integers(20, len(te) - 60))
    seg = te3.loc[st:st + 39, "market_total"]
    te3.loc[st:st + 39, "market_total"] = seg.mean() + 3 * (seg - seg.mean())
    te3.loc[st:st + 39, "mkt_rf"] = te3.loc[st:st + 39, "market_total"] - te3.loc[st:st + 39, "rf"]
    for name, pol, strat in [("fd", pol_fd, "fd_reference"), ("fd_misspec", pol_m, "fd_reference"),
                             ("fixed_50", None, "fixed_50"), ("market_100", None, "market_100")]:
        tw_, pm_ = run(te3, p, strat, pol)
        spike_rows.append((year, name, tw_, pm_))
    print("stress", year, flush=True)

stress = []
for (x, name), v in agg.items():
    v = np.array(v)
    stress.append({"shock": x, "policy": name, "n": len(v), "min_terminal": v[:, 0].min(),
                   "terminal_breach_rate(F=0.30)": float((v[:, 0] < 0.30).mean()),
                   "pathwise_breach_rate(F=0.30)": float((v[:, 1] < 0).mean()),
                   "worst_pathwise_margin": v[:, 1].min()})
pd.DataFrame(stress).sort_values(["shock", "policy"]).to_csv(out_dir / "stress_gap_shocks.csv", index=False)
sp = pd.DataFrame(spike_rows, columns=["year", "policy", "terminal", "path_margin"])
res["vol_spike_x3_40d"] = {k: {"min_terminal": float(g.terminal.min()), "pathwise_breaches": int((g.path_margin < 0).sum()),
                                "n": int(len(g))} for k, g in sp.groupby("policy")}

# (FD convergence over all folds is in followup_convergence_and_regimes.py, which excludes the solver's end-node artifact)

json.dump(res, open(out_dir / "evidence.json", "w"), indent=2, default=float)
print(json.dumps(res, indent=2, default=float))
print(pd.DataFrame(stress).sort_values(["shock", "policy"]).to_string())
