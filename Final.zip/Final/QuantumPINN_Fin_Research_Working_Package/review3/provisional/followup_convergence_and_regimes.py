import sys, types
from pathlib import Path
import numpy as np, pandas as pd
pkg_root, csv_path, out = map(Path, sys.argv[1:4])
sys.path.insert(0, str(pkg_root/"implementation"/"qpinn_fin"))
from qpinn_fin.reference import solve_fd
src=(pkg_root/"historical"/"walk_forward_backtest.py").read_text()
for b in ["import torch\n","from qpinn_fin.trainer import train\n","from qpinn_fin.hjb import derivs, policy_raw\n"]: src=src.replace(b,"")
mod=types.ModuleType("w"); mod.__dict__["__file__"]=str(pkg_root/"historical"/"walk_forward_backtest.py"); exec(compile(src,"w","exec"),mod.__dict__)
f=pd.read_csv(out/"fold_results_numpy_rerun.csv")
# (b) NaN Sharpe
nan=f[f.sharpe_vs_rf.isna()].groupby("strategy").test_year.apply(list)
print("NaN Sharpe folds:\n",nan.to_string())
fd=f[f.strategy=="fd_reference"].set_index("test_year"); fx=f[f.strategy=="fixed_50"].set_index("test_year"); mk=f[f.strategy=="market_100"].set_index("test_year")
common=fd.sharpe_vs_rf.dropna().index
print("like-for-like Sharpe over %d common folds: FD %.4f  fixed50 %.4f  market %.4f"%(len(common),fd.sharpe_vs_rf[common].mean(),fx.sharpe_vs_rf[common].mean(),mk.sharpe_vs_rf[common].mean()))
# (c) regime behaviour
tab=pd.DataFrame({"piM":fd.pi_M,"fd_cagr":fd.cagr,"mkt_cagr":mk.cagr,"fd_minus_mkt":fd.cagr-mk.cagr,"fd_turnover":fd.turnover_abs_weight})
tab["regime"]=np.where(tab.piM<0,"piM<0",np.where(tab.piM<=1,"0..1",">1"))
print(tab.groupby("regime")[["fd_cagr","mkt_cagr","fd_minus_mkt"]].agg(["mean","count"]).round(4).to_string())
print(tab.round(3).to_string())
ex=mk.cagr  # realised market CAGR that year
from scipy import stats
print("corr(clip(piM,0,1), same-year market CAGR): ", stats.spearmanr(tab.piM.clip(0,1), mk.cagr))
# saturation in FD allocation targets
p=pd.read_csv(out/"paths_numpy_rerun.csv.gz"); r=p[(p.strategy=="fd_reference")&(p.is_rebalance_day)]
tw=r.target_weight; print("FD rebalances",len(tw),"zero",(tw<0.02).sum(),"one",(tw>0.98).sum(),"interior",((tw>=0.02)&(tw<=0.98)).sum())
# (a) convergence, interior only (exclude boundary cells: FD policy at the two end nodes is 0 by construction)
rows=[]
cg=np.geomspace(0.1,4.0,300)
for year in range(2000,2026):
    tr=None
    df=pd.read_csv(csv_path,parse_dates=["date"]).sort_values("date") if year==2000 else df
    tr=df[(df.date>=pd.Timestamp(year-5,1,1))&(df.date<pd.Timestamp(year,1,1))]
    pr=mod.estimate_params(tr,2.0,0.30,0.05,5.0); sols={}
    for tag,(nx,nt) in {"coarse":(120,6000),"default":(240,12000),"fine":(360,18000)}.items():
        dx=(np.log(pr.cmax)-np.log(pr.cmin))/nx; need=int(np.ceil(pr.T*(1+pr.F/pr.cmin)**2*pr.sigma**2/(0.9*dx**2)*1.02)); nte=max(nt,need+(-need)%40)
        sols[tag]=(solve_fd(pr,cap=True,Nx=nx,Nt=nte,n_save=40),nte!=nt)
    def field(s): return np.clip(np.array([np.interp(np.log(cg),s.x,s.pi[i]) for i in range(len(s.t))]),0,1)
    ref=field(sols["fine"][0]); zone=(ref>0.02)&(ref<0.98)
    for tag in ["coarse","default"]:
        e=np.abs(field(sols[tag][0])-ref)
        rows.append(dict(year=year,grid=tag,piM=pr.merton_fraction,sigma=pr.sigma,nt_raised=sols[tag][1],interior_frac=zone.mean(),mae=e.mean(),max_all=e.max(),max_transition=e[zone].max() if zone.any() else np.nan))
cv=pd.DataFrame(rows); cv.to_csv(out/"fd_convergence_interior_all_folds.csv",index=False)
cv["regime"]=np.where(cv.piM<0,"piM<0",np.where(cv.piM<=1,"0..1",">1"))
print(cv.groupby(["grid","regime"]).agg(folds=("year","count"),mae=("mae","mean"),max_all=("max_all","max"),max_trans=("max_transition","max"),raised=("nt_raised","sum"),interior=("interior_frac","mean")).to_string())
print("worst default:\n",cv[cv.grid=="default"].sort_values("max_all",ascending=False).head(5).to_string())
