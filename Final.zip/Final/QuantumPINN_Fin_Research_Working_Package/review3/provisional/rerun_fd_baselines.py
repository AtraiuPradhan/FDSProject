"""Numpy-only rerun of the Review-2 walk-forward for FD reference + baselines.

Imports the project's own config/reference/simulate logic (no torch needed): the FD solver lives in
qpinn_fin.reference, and simulate()/metrics()/estimate_params() are copied verbatim from
historical/walk_forward_backtest.py (that module imports torch at top level, so it cannot be imported here).
Usage: python rerun_fd_baselines.py <pkg_root> <csv> <out_dir>
"""
import sys, types, json
from pathlib import Path
import numpy as np
import pandas as pd

pkg_root, csv_path, out_dir = map(Path, sys.argv[1:4])
sys.path.insert(0, str(pkg_root / "implementation" / "qpinn_fin"))
from qpinn_fin.config import Params          # noqa: E402
from qpinn_fin.reference import solve_fd     # noqa: E402

# --- pull simulate/metrics/estimate_params/fd_* out of the original file without executing its torch import
src = (pkg_root / "historical" / "walk_forward_backtest.py").read_text()
src = src.replace("import torch\n", "").replace("from qpinn_fin.trainer import train\n", "")
src = src.replace("from qpinn_fin.hjb import derivs, policy_raw\n", "")
mod = types.ModuleType("wfb"); mod.__dict__["__file__"] = str(pkg_root / "historical" / "walk_forward_backtest.py")
exec(compile(src, "wfb", "exec"), mod.__dict__)

df = pd.read_csv(csv_path, parse_dates=["date"]).sort_values("date").dropna().reset_index(drop=True)
out_dir.mkdir(parents=True, exist_ok=True)
rows, paths = [], []
for year in range(2000, 2026):
    tr = df[(df.date >= pd.Timestamp(year - 5, 1, 1)) & (df.date < pd.Timestamp(year, 1, 1))]
    te = df[(df.date >= pd.Timestamp(year, 1, 1)) & (df.date < pd.Timestamp(year + 1, 1, 1))]
    p = mod.estimate_params(tr, 2.0, 0.30, 0.05, 5.0)
    sol = solve_fd(p, cap=True, Nx=240, Nt=12000, n_save=40)
    pol = {"fd_reference": lambda c, t, sol=sol: mod.fd_policy(sol, c, t)}
    for s in ["fd_reference", "constant_merton_no_floor", "fixed_50", "market_100", "cash_0"]:
        met = mod.simulate(te, p, s, pol.get(s), 21, 10 / 1e4, save_path=True)
        pr = met.pop("allocation_path")
        for r in pr:
            r["test_year"] = year
        paths.extend(pr)
        rows.append({"test_year": year, "strategy": s, "mu": p.mu, "r": p.r, "sigma": p.sigma,
                     "pi_M": p.merton_fraction, **met})
    print(year, f"pi_M={p.merton_fraction:.3f}", flush=True)

fold = pd.DataFrame(rows)
fold.to_csv(out_dir / "fold_results_numpy_rerun.csv", index=False)
pd.DataFrame(paths).to_csv(out_dir / "paths_numpy_rerun.csv.gz", index=False)
summ = fold.groupby("strategy").agg(folds=("test_year", "nunique"), mean_cagr=("cagr", "mean"),
        median_cagr=("cagr", "median"), mean_sharpe=("sharpe_vs_rf", "mean"),
        mean_vol=("annualized_volatility", "mean"), mean_mdd=("max_drawdown", "mean"),
        breach=("terminal_floor_breach", "mean"), turnover=("turnover_abs_weight", "mean")).reset_index()
summ.to_csv(out_dir / "summary_numpy_rerun.csv", index=False)
print(summ.to_string())
