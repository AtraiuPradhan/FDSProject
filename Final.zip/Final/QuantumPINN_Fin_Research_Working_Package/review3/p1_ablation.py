"""P1: physics-loss and architecture ablations, matched parameter / runtime budgets, PDE & boundary errors.

Covers reviewer items
  - Classical PINN without HJB residual / without boundary loss          (B2_noHJB, B2_noBC; B5_noHJB)
  - B5 with different circuit depths                                       (B5_L1, B5_L2, B5, B5_L6)
  - B5 with fewer re-uploading layers                                      (B5_L4_up1, B5_L4_up2 vs B5)
  - Equal-parameter B2 vs B5                                               (B2 ~51 params vs B5 53; B2m_L* match each depth)
  - Equal-runtime B2 vs B5                                                 (B2_eqtime trains until B5's wall-clock is reached)
  - Different floor values / risk-aversion coefficients                    (presets floor, gamma)
  - HJB residual norms, boundary / terminal errors, policy errors, training time (every row)
  - Loss-treatment and entangler context                                   (B1, B4 penalty variants; B3 no entanglers)

Every trained model is scored against the FD reference of the SAME parameters on held-out (c,t) points
(interior only; the FD solver's two end nodes are excluded).

Examples (run from the package root):
  python review3/p1_ablation.py --preset core --seeds 0 1 2 3 4 --workers 2
  python review3/p1_ablation.py --preset regimes --seeds 0 1 2 --workers 2
  python review3/p1_ablation.py --preset floor gamma --seeds 0 1 2 --workers 2
  python review3/p1_ablation.py --summarize-only
Results append to review3/out/ablation.jsonl (resumable: finished (instance, seed) units are skipped).
"""
from __future__ import annotations

import argparse
import json
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

from r3_common import OUT_DEFAULT, fold_params, load_data, regime_of, solve_fd_stable, bootstrap_ci

N_QUBITS = 4

# name -> spec.  kind: q = circuit, mlp = parameter-matched to B5 (original build('mlp')), mlpm = matched to `match`
SPECS = {
    "B5":         dict(kind="q", L=4, up=4, ent="ring", mode="cc"),
    "B2":         dict(kind="mlp", mode="cc"),
    "B2_eqtime":  dict(kind="mlp", mode="cc", time_from="B5"),
    "B2_eqtime_up1": dict(kind="mlp", mode="cc", time_from="B5_L4_up1"),
    "B2_noHJB":   dict(kind="mlp", mode="cc", lam_pde=0.0),
    "B2_noBC":    dict(kind="mlp", mode="cc", lam_bd=0.0),
    "B5_noHJB":   dict(kind="q", L=4, up=4, ent="ring", mode="cc", lam_pde=0.0),
    "B1":         dict(kind="mlp", mode="pen"),
    "B3":         dict(kind="q", L=4, up=4, ent="none", mode="cc"),
    "B4":         dict(kind="q", L=4, up=4, ent="ring", mode="pen"),
    "B5_L1":      dict(kind="q", L=1, up=1, ent="ring", mode="cc"),
    "B5_L2":      dict(kind="q", L=2, up=2, ent="ring", mode="cc"),
    "B5_L6":      dict(kind="q", L=6, up=6, ent="ring", mode="cc"),
    "B2m_L1":     dict(kind="mlpm", match="B5_L1", mode="cc"),
    "B2m_L2":     dict(kind="mlpm", match="B5_L2", mode="cc"),
    "B2m_L6":     dict(kind="mlpm", match="B5_L6", mode="cc"),
    "B5_L4_up1":  dict(kind="q", L=4, up=1, ent="ring", mode="cc"),
    "B5_L4_up2":  dict(kind="q", L=4, up=2, ent="ring", mode="cc"),
    # untrained controls: how much of the policy is already fixed by the trial form V = u(c) exp((T-t) S) and the S window?
    "B2_init":    dict(kind="mlp", mode="cc", steps0=True),
    "B5_init":    dict(kind="q", L=4, up=4, ent="ring", mode="cc", steps0=True),
}
FULL = ["B5", "B2", "B2_eqtime", "B2_noHJB", "B2_noBC", "B5_noHJB", "B1", "B3", "B4",
        "B5_L1", "B5_L2", "B5_L6", "B2m_L1", "B2m_L2", "B2m_L6", "B5_L4_up1", "B5_L4_up2", "B2_init", "B5_init"]
LIGHT = ["B5", "B2", "B2_eqtime", "B2_init", "B5_init"]


def make_instances(presets, base_year):
    inst = {}
    def add(name, year, gamma=2.0, floor=0.30, variants=LIGHT):
        inst[name] = dict(name=name, year=year, gamma=gamma, floor=floor, variants=variants)
    for pr in presets:
        if pr == "eqtime":   # B2 given the same wall-clock as B5, on the cap-binding folds where B5 showed lower value error
            for y in (2014, 2008):
                add(f"fold{y}_eqtime", y, variants=["B5", "B2", "B2_eqtime"])
        if pr == "init":   # the first experiment to run: does the trial form alone already give the policy?
            add(f"fold{base_year}_init", base_year, variants=["B2_init", "B2", "B2_noHJB", "B5_init", "B5"])
        if pr == "followup":
            add(f"fold{base_year}_followup", base_year, variants=["B5_L4_up1", "B2_eqtime_up1", "B2"])
        if pr in ("core", "all"):
            add(f"fold{base_year}", base_year, variants=FULL)
        if pr in ("regimes", "all"):
            for y in (2002, 2006, 2013, 2008, 2014, 2003):        # 0..1 regime x3, >1 regime x2, <0 regime x1
                add(f"fold{y}", y)
        if pr in ("floor", "all"):
            for F in (0.1, 0.3, 0.5, 0.7, 0.9):
                add(f"F{F}_fold{base_year}", base_year, floor=F)
        if pr in ("gamma", "all"):
            for g in (0.5, 1.5, 2.0, 3.0, 5.0, 10.0):             # gamma = 1 is excluded (log utility is a different trial form)
                add(f"gamma{g}_fold{base_year}", base_year, gamma=g)
    return list(inst.values())


_FD_CACHE = {}


def _build(name, p, exps, seed, cache_counts):
    import torch
    from qpinn_fin.models import build
    from r3_models import QuantumSReupload, mlp_matching
    spec = SPECS[name]
    torch.manual_seed(seed)
    if spec["kind"] == "q":
        m = QuantumSReupload(p, exps, N_QUBITS, spec["L"], spec["up"], spec["ent"])
    elif spec["kind"] == "mlp":
        m = build("mlp", p, exps, N_QUBITS, 4)                 # exactly the paper's B2 (parameter-matched to B5)
    else:
        m = mlp_matching(p, exps, cache_counts[spec["match"]])
    cache_counts[name] = m.n_params()
    return m


def run_unit(job):
    inst, seed, steps, threads = job
    import torch
    torch.set_num_threads(threads)
    from r3_train import evaluate_model, train_ext
    df = load_data(job_data_path)
    p = fold_params(df, inst["year"], inst["gamma"], inst["floor"])
    key = (inst["year"], inst["gamma"], inst["floor"])
    if key not in _FD_CACHE:
        _FD_CACHE[key] = solve_fd_stable(p)
    sol = _FD_CACHE[key]
    from qpinn_fin.trainer import boundary_exponents
    exps = boundary_exponents(p)
    rows, counts, times = [], {}, {}
    # counts of circuit parameters are needed before building matched MLPs
    for nm in ("B5_L1", "B5_L2", "B5_L6"):
        counts[nm] = 12 * SPECS[nm]["L"] + N_QUBITS + 1
    for name in inst["variants"]:
        spec = SPECS[name]
        base = dict(instance=inst["name"], year=inst["year"], gamma=inst["gamma"], floor=inst["floor"],
                    seed=seed, variant=name, steps=steps, mu=p.mu, r=p.r, sigma=p.sigma,
                    merton_fraction=p.merton_fraction, regime=regime_of(p.merton_fraction))
        try:
            model = _build(name, p, exps, seed, counts)
            tb = times.get(spec.get("time_from")) if spec.get("time_from") else None
            info = train_ext(model, p, mode=spec["mode"], seed=seed, steps=0 if spec.get("steps0") else steps, time_budget=tb,
                             lam_pde=spec.get("lam_pde", 1.0), lam_bd=spec.get("lam_bd", 1.0))
            times[name] = info["train_time"]
            met = evaluate_model(model, p, sol)
            rows.append({**base, **info, **met})
        except Exception as e:                                   # keep the sweep alive; record the failure
            rows.append({**base, "error": f"{type(e).__name__}: {e}"})
        print(f"[{inst['name']} seed{seed}] {name}: " + (f"policy_rmse={rows[-1].get('policy_rmse', float('nan')):.3g} "
              f"resid_rms={rows[-1].get('hjb_resid_rms', float('nan')):.3g} t={rows[-1].get('train_time', float('nan')):.1f}s"
              if "error" not in rows[-1] else rows[-1]["error"]), flush=True)
    return inst["name"], seed, rows


job_data_path = None


def summarize(out_dir: Path):
    path = out_dir / "ablation.jsonl"
    df = pd.DataFrame([json.loads(l) for l in path.read_text().splitlines() if l.strip()])
    if "error" in df:
        bad = df[df["error"].notna()]
        if len(bad):
            print(f"{len(bad)} failed runs (see ablation_errors.csv)")
            bad.to_csv(out_dir / "ablation_errors.csv", index=False)
        df = df[df["error"].isna()]
    metrics = ["n_params", "train_time", "steps_done", "value_rel_l2", "policy_rmse", "policy_max_abs", "policy_rmse_transition",
               "hjb_resid_rms", "hjb_resid_max_abs", "bc_lo_max_abs", "bc_hi_max_abs", "terminal_rel_max",
               "frac_Vcc_nonneg", "frac_Vc_nonpos"]
    g = df.groupby(["instance", "variant"])
    summ = g[metrics].agg(["mean", "std"]); summ.columns = ["_".join(c) for c in summ.columns]
    summ["n_seeds"] = g.size()
    summ.reset_index().to_csv(out_dir / "ablation_summary.csv", index=False)
    # paired seed-wise differences against B2 and against B5 (same instance, same seed)
    rng = np.random.default_rng(1)
    prow = []
    for inst, d in df.groupby("instance"):
        piv = d.pivot_table(index="seed", columns="variant", values=["policy_rmse", "hjb_resid_rms", "train_time"])
        for ref in ("B2", "B5"):
            for var in sorted(set(d.variant) - {ref}):
                for m in ("policy_rmse", "hjb_resid_rms"):
                    if (m, var) in piv and (m, ref) in piv:
                        x = (piv[(m, var)] - piv[(m, ref)]).dropna().to_numpy()
                        if len(x):
                            lo, hi = bootstrap_ci(x, rng, nboot=5000)
                            prow.append(dict(instance=inst, variant=var, reference=ref, metric=m, n_seeds=len(x),
                                             mean_diff=float(x.mean()), ci95_lo=lo, ci95_hi=hi,
                                             frac_seeds_variant_lower=float((x < 0).mean())))
    pd.DataFrame(prow).to_csv(out_dir / "ablation_paired_diffs.csv", index=False)
    show = summ.reset_index()[["instance", "variant", "n_params_mean", "train_time_mean", "policy_rmse_mean", "policy_rmse_std",
                               "hjb_resid_rms_mean", "bc_hi_max_abs_mean", "frac_Vcc_nonneg_mean", "n_seeds"]]
    with pd.option_context("display.width", 200, "display.max_rows", 500, "display.float_format", "{:.3g}".format):
        print(show.to_string(index=False))
    print(f"\nWrote {out_dir/'ablation_summary.csv'} and {out_dir/'ablation_paired_diffs.csv'}")


def main():
    global job_data_path
    ap = argparse.ArgumentParser()
    ap.add_argument("--preset", nargs="+", default=["core"], choices=["init", "eqtime", "core", "regimes", "floor", "gamma", "followup", "all"])
    ap.add_argument("--base-year", type=int, default=2006, help="fold whose estimated mu, r, sigma define the base instance")
    ap.add_argument("--steps", type=int, default=500, help="500 matches the walk-forward runs")
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--data", default=None)
    ap.add_argument("--out", default=str(OUT_DEFAULT))
    ap.add_argument("--summarize-only", action="store_true")
    a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    if a.summarize_only:
        return summarize(out)
    job_data_path = a.data
    path = out / "ablation.jsonl"
    done = set()
    if path.exists():
        for l in path.read_text().splitlines():
            if l.strip():
                r = json.loads(l); done.add((r["instance"], r["seed"]))
    jobs = [(i, s, a.steps, 1 if a.workers > 1 else 0) for i in make_instances(a.preset, a.base_year) for s in a.seeds
            if (i["name"], s) not in done]
    jobs = [(i, s, st, th if th else __import__("torch").get_num_threads()) for i, s, st, th in jobs]
    print(f"{len(jobs)} units to run ({len(done)} already done)", flush=True)
    t0 = time.time()
    if a.workers > 1:
        # each worker re-imports this module; pass the data path via a module global initialiser
        with ProcessPoolExecutor(a.workers, initializer=_init, initargs=(a.data,)) as ex:
            futs = [ex.submit(run_unit, j) for j in jobs]
            for f in as_completed(futs):
                _, _, rows = f.result()
                with path.open("a") as fh:
                    for r in rows:
                        fh.write(json.dumps(r) + "\n")
    else:
        for j in jobs:
            _, _, rows = run_unit(j)
            with path.open("a") as fh:
                for r in rows:
                    fh.write(json.dumps(r) + "\n")
    print(f"done in {(time.time()-t0)/60:.1f} min")
    summarize(out)


def _init(data_path):
    global job_data_path
    job_data_path = data_path


if __name__ == "__main__":
    main()
