"""Shared helpers for the Review-3 (P1) scripts.

Place the `review3/` folder at the package root (next to `implementation/` and `historical/`).
Everything here imports the project's own code; nothing in the original package is modified.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "implementation" / "qpinn_fin"))
sys.path.insert(0, str(ROOT / "historical"))
DATA_DEFAULT = ROOT / "historical" / "data" / "french_daily_market_rf.csv"
OUT_DEFAULT = ROOT / "review3" / "out"

import walk_forward_backtest as wfb                      # noqa: E402  (needs torch)
from qpinn_fin.config import Params                      # noqa: E402
from qpinn_fin.reference import solve_fd                 # noqa: E402

YEARS = list(range(2000, 2026))


def load_data(path=None) -> pd.DataFrame:
    path = Path(path) if path else DATA_DEFAULT
    if not path.exists():
        raise SystemExit(f"Dataset not found: {path}\nCopy french_daily_market_rf.csv to historical/data/ or pass --data")
    df = pd.read_csv(path, parse_dates=["date"]).sort_values("date")
    return df.dropna(subset=["date", "mkt_rf", "rf", "market_total"]).reset_index(drop=True)


def fold_split(df: pd.DataFrame, year: int, train_years: int = 5):
    tr = df[(df.date >= pd.Timestamp(year - train_years, 1, 1)) & (df.date < pd.Timestamp(year, 1, 1))]
    te = df[(df.date >= pd.Timestamp(year, 1, 1)) & (df.date < pd.Timestamp(year + 1, 1, 1))].reset_index(drop=True)
    return tr, te


def fold_params(df, year, gamma=2.0, floor=0.30, cmin=0.05, cmax=5.0, train_years=5) -> Params:
    tr, _ = fold_split(df, year, train_years)
    return wfb.estimate_params(tr, gamma, floor, cmin, cmax)


def stable_nt(p: Params, nx: int, nt: int, n_save: int = 40) -> int:
    """Smallest Nt >= nt satisfying solve_fd's explicit-scheme stability bound, divisible by n_save."""
    dx = (np.log(p.cmax) - np.log(p.cmin)) / nx
    need = int(np.ceil(p.T * (1 + p.F / p.cmin) ** 2 * p.sigma ** 2 / (0.9 * dx ** 2) * 1.02))
    nt_eff = max(nt, need)
    return nt_eff + (-nt_eff) % n_save


def solve_fd_stable(p: Params, nx: int = 240, nt: int = 12000, n_save: int = 40):
    return solve_fd(p, cap=True, Nx=nx, Nt=stable_nt(p, nx, nt, n_save), n_save=n_save)


def regime_of(pi_m: float) -> str:
    return "piM<0" if pi_m < 0 else ("0<=piM<=1" if pi_m <= 1 else "piM>1")


def bootstrap_ci(x: np.ndarray, rng, nboot=20000, block=1, alpha=0.05):
    """Percentile CI for the mean of x; block>1 = moving-block bootstrap (for serial dependence)."""
    x = np.asarray(x, float); n = len(x)
    if n == 0:
        return (np.nan, np.nan)
    if block <= 1:
        m = x[rng.integers(0, n, (nboot, n))].mean(axis=1)
    else:
        nb = int(np.ceil(n / block)); block = min(block, n)
        st = rng.integers(0, n - block + 1, (nboot, nb))
        idx = (st[:, :, None] + np.arange(block)[None, None, :]).reshape(nboot, -1)[:, :n]
        m = x[idx].mean(axis=1)
    return (float(np.percentile(m, 100 * alpha / 2)), float(np.percentile(m, 100 * (1 - alpha / 2))))
