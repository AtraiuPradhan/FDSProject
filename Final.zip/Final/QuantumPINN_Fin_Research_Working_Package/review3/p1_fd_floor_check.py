"""Is the shared policy error at gamma = 5 and 10 the FD reference's own error?   (paper Section 5.11, "FD reference check")

Fold 2014, floor F = 0.30, gamma in {2, 3, 5, 10}. For each gamma:
  (a) policy RMSE / max between the default FD grid (240 x 12,000, the reference used to score every model) and the finest grid
      (480 x 32,000) on exactly the model-evaluation points;
  (b) B2 (seed 0, 500 steps) and its untrained control scored against both grids.
Run from the package root:   python review3/p1_fd_floor_check.py        (a few minutes; writes review3/out/fd_floor_check.json)
"""
from __future__ import annotations

import argparse
import json

import numpy as np
import torch

from r3_common import OUT_DEFAULT, fold_params, load_data, solve_fd_stable, stable_nt
from qpinn_fin.models import build
from qpinn_fin.reference import solve_fd
from qpinn_fin.trainer import boundary_exponents
from r3_train import EDGE_HI, evaluate_model, train_ext


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=None)
    ap.add_argument("--out", default=str(OUT_DEFAULT))
    ap.add_argument("--year", type=int, default=2014)
    ap.add_argument("--gammas", nargs="+", type=float, default=[2.0, 3.0, 5.0, 10.0])
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    df = load_data(a.data)
    out = {}
    for g in a.gammas:
        p = fold_params(df, a.year, g, 0.30)
        d = solve_fd_stable(p)                                                  # default grid, as used for all model scores
        f = solve_fd(p, cap=True, Nx=480, Nt=stable_nt(p, 480, 32000, 40), n_save=40)   # finest grid
        c = np.geomspace(0.1, EDGE_HI * p.cmax, 200)
        diffs = []
        for i in range(len(d.t) - 1):
            _, pd_ = d.interp(i, c)
            _, pf = f.interp(i, c)
            diffs.append(pd_ - pf)
        diffs = np.concatenate(diffs)
        exps = boundary_exponents(p)
        torch.manual_seed(a.seed)
        m = build("mlp", p, exps, 4, 4)
        train_ext(m, p, mode="cc", seed=a.seed, steps=a.steps)
        e_def, e_fin = evaluate_model(m, p, d), evaluate_model(m, p, f)
        torch.manual_seed(a.seed)
        m0 = build("mlp", p, exps, 4, 4)                                        # untrained control, same seed
        i_def, i_fin = evaluate_model(m0, p, d), evaluate_model(m0, p, f)
        out[str(g)] = dict(pi_M=p.merton_fraction,
                           fd_default_vs_finest_rmse=float(np.sqrt(np.mean(diffs ** 2))),
                           fd_default_vs_finest_max=float(np.abs(diffs).max()),
                           B2_vs_default=e_def["policy_rmse"], B2_vs_finest=e_fin["policy_rmse"],
                           B2init_vs_default=i_def["policy_rmse"], B2init_vs_finest=i_fin["policy_rmse"])
        print(g, json.dumps(out[str(g)]), flush=True)
    from pathlib import Path
    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "fd_floor_check.json").write_text(json.dumps(out, indent=1))
    print(f"\nWrote {out_dir / 'fd_floor_check.json'}")


if __name__ == "__main__":
    main()
