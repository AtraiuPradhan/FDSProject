"""Training with switchable loss terms / wall-clock budget, and a full diagnostic evaluation.

train_ext mirrors qpinn_fin.trainer.train (same sampling, loss, optimiser, clipping) and adds
  * lam_pde, lam_bd : weights of the HJB-residual and boundary losses (0 switches a term off)
  * time_budget     : stop after this many seconds (learning rate decays 10x over the budget)
evaluate_model reports value / policy error against the FD reference, HJB residual norms,
boundary and terminal errors, and concavity diagnostics (is V_cc < 0 and V_c > 0 actually true?).
"""
from __future__ import annotations

import math
import time

import numpy as np
import torch

from qpinn_fin.config import Params
from qpinn_fin.hjb import derivs, policy_raw, residual
from qpinn_fin.trainer import boundary_exponents, sample

EDGE_HI = 0.8   # evaluate only below 0.8*cmax: the FD solver's two end nodes are not valid policy points


def train_ext(model, p: Params, mode: str = "cc", seed: int = 0, steps: int = 500, time_budget: float | None = None,
              lam_pde: float = 1.0, lam_bd: float = 1.0, lam_pen: float = 1.0, n_int: int = 192, n_bd: int = 32,
              lr: float = 1e-2):
    exps = boundary_exponents(p)
    s_lo, s_hi = exps
    gen = torch.Generator().manual_seed(seed + 12345)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = None if time_budget else torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.1 ** (1.0 / max(steps, 1)))
    t0, k = time.time(), 0
    last = {}
    while True:
        elapsed = time.time() - t0
        if time_budget is not None:
            if elapsed >= time_budget:
                break
            for g in opt.param_groups:
                g["lr"] = lr * 0.1 ** (elapsed / time_budget)
        elif k >= steps:
            break
        c, t = sample(n_int, p, gen)
        V, V_t, V_c, V_cc, cl, tl = derivs(model, c, t)
        R, raw = residual(V_t, V_c, V_cc, cl, tl, p, mode=mode)
        u = (cl ** (1 - p.gamma) / (1 - p.gamma)).abs()
        loss_pde = ((R / u) ** 2).mean()
        tb = p.T * torch.rand(n_bd, generator=gen)
        S_lo = model.S(torch.full_like(tb, p.cmin), tb)
        S_hi = model.S(torch.full_like(tb, p.cmax), tb)
        loss_bd = ((S_lo - s_lo) ** 2).mean() + ((S_hi - s_hi) ** 2).mean()
        loss = lam_pde * loss_pde + lam_bd * loss_bd
        if mode == "pen":
            viol = torch.relu(raw - 1.0) ** 2 + torch.relu(-raw) ** 2
            loss = loss + lam_pen * viol.mean()
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
        opt.step()
        if sched is not None:
            sched.step()
        k += 1
        last = {"loss_pde_last": float(loss_pde.detach()), "loss_bd_last": float(loss_bd.detach())}
    return {"steps_done": k, "train_time": time.time() - t0, "n_params": model.n_params(), **last}


def _fields(model, p, c, t):
    ct = torch.as_tensor(np.asarray(c, float))
    tt = torch.full_like(ct, float(t))
    V, V_t, V_c, V_cc, cl, tl = derivs(model, ct, tt, create_graph=False)
    raw = policy_raw(V_c, V_cc, cl, tl, p)
    return V, V_t, V_c, V_cc, raw, cl, tl


def evaluate_model(model, p: Params, sol, n_c: int = 200, n_resid: int = 4000, seed: int = 999) -> dict:
    """All numbers are on held-out points; FD reference `sol` must come from solve_fd on the same Params."""
    exps = boundary_exponents(p)
    c = np.geomspace(0.1, EDGE_HI * p.cmax, n_c)
    eV, ePi, eTr, eSat, viol_cc, viol_vc, rres = [], [], [], [], [], [], []
    for i, t in enumerate(sol.t[:-1]):
        V, V_t, V_c, V_cc, raw, cl, tl = _fields(model, p, c, t)
        Vr, pir = sol.interp(i, c)
        pm = np.clip(raw.detach().numpy(), 0, 1)
        eV.append(np.sqrt(np.mean(((V.detach().numpy() - Vr) / np.abs(Vr)) ** 2)))
        d = pm - pir
        ePi.append(d)
        zone = (pir > 0.02) & (pir < 0.98)
        eTr.append(d[zone]); eSat.append(d[~zone])
        viol_cc.append(np.mean(V_cc.detach().numpy() >= -p.eps))
        viol_vc.append(np.mean(V_c.detach().numpy() <= 0))
    allpi = np.concatenate(ePi); tr = np.concatenate(eTr); sat = np.concatenate(eSat)
    # HJB residual on random held-out (c,t), log-uniform in c over the evaluation window, normalised by |u|
    g = torch.Generator().manual_seed(seed)
    lc = math.log(0.1) + (math.log(EDGE_HI * p.cmax) - math.log(0.1)) * torch.rand(n_resid, generator=g)
    tt = p.T * torch.rand(n_resid, generator=g)
    V, V_t, V_c, V_cc, cl, tl = derivs(model, torch.exp(lc), tt, create_graph=False)
    R, _ = residual(V_t, V_c, V_cc, cl, tl, p, mode="cc")
    rn = (R / (cl ** (1 - p.gamma) / (1 - p.gamma)).abs()).detach().numpy()
    # boundary (S pinned at truncation edges) and terminal condition
    tb = torch.linspace(0, p.T, 101)
    s_lo = model.S(torch.full_like(tb, p.cmin), tb).detach().numpy() - exps[0]
    s_hi = model.S(torch.full_like(tb, p.cmax), tb).detach().numpy() - exps[1]
    cT = torch.as_tensor(np.geomspace(p.cmin, p.cmax, 50))
    VT = model.V(cT, torch.full_like(cT, p.T)).detach().numpy()
    uT = (cT ** (1 - p.gamma) / (1 - p.gamma)).numpy()
    return {
        "value_rel_l2": float(np.mean(eV)),
        "policy_rmse": float(np.sqrt(np.mean(allpi ** 2))), "policy_mae": float(np.mean(np.abs(allpi))),
        "policy_max_abs": float(np.max(np.abs(allpi))),
        "policy_rmse_transition": float(np.sqrt(np.mean(tr ** 2))) if tr.size else float("nan"),
        "policy_rmse_saturated": float(np.sqrt(np.mean(sat ** 2))) if sat.size else float("nan"),
        "transition_fraction": float(tr.size / allpi.size),
        "hjb_resid_rms": float(np.sqrt(np.mean(rn ** 2))), "hjb_resid_median_abs": float(np.median(np.abs(rn))),
        "hjb_resid_max_abs": float(np.max(np.abs(rn))),
        "bc_lo_mean_abs": float(np.mean(np.abs(s_lo))), "bc_lo_max_abs": float(np.max(np.abs(s_lo))),
        "bc_hi_mean_abs": float(np.mean(np.abs(s_hi))), "bc_hi_max_abs": float(np.max(np.abs(s_hi))),
        "terminal_rel_max": float(np.max(np.abs((VT - uT) / np.abs(uT)))),
        "frac_Vcc_nonneg": float(np.mean(viol_cc)),     # concavity violated (clamp in policy_raw activates)
        "frac_Vc_nonpos": float(np.mean(viol_vc)),      # marginal value not positive
    }
