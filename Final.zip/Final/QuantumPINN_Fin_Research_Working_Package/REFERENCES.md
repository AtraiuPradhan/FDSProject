# References to verify against original full texts

1. Wang, L., Lisser, A., Sreekumar, S., & Toffano, Z. (2026). *Learning PDEs for Portfolio Optimization with Quantum Physics-Informed Neural Networks*. arXiv:2604.03346. https://arxiv.org/abs/2604.03346
2. Kim, Y., Kim, Y., Kim, M., & Cho, N. (2025; later version listed in 2026). *Neural Policy Iteration for Stochastic Optimal Control: A Physics-Informed Approach*. arXiv:2508.01718. https://arxiv.org/abs/2508.01718
3. Merton, R. C. (1969). *Lifetime Portfolio Selection under Uncertainty: The Continuous-Time Case*. The Review of Economics and Statistics, 51(3), 247–257. Verify the bibliographic record against the original publication.

The two arXiv papers are the closest currently identified sources. The Merton reference is a foundational background source. Download and inspect original PDFs before final submission; links are provided here, but the PDFs are not yet bundled in this package.
