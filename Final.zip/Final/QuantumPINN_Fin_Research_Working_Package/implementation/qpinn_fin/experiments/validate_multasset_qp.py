"""Cross-check the active-set simplex QP solver against SciPy SLSQP.

Run from implementation/qpinn_fin:
    PYTHONPATH=. python experiments/validate_multasset_qp.py --cases 500 --seed 7
SciPy is needed only for this validation script, not by multasset_qp.py itself.
"""
import argparse
import numpy as np
from scipy.optimize import minimize
from qpinn_fin.multasset_qp import solve_simplex_qp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--cases', type=int, default=500)
    ap.add_argument('--seed', type=int, default=7)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    max_gap = 0.0
    max_violation = 0.0
    checked = 0
    for _ in range(args.cases):
        d = 3
        A = rng.normal(size=(d, d))
        Sigma = A.T @ A + 0.2 * np.eye(d)
        b = rng.normal(size=d) + 0.8
        lam = 10 ** rng.uniform(-1, 1)
        budget = rng.uniform(0.1, 1.0)
        pi = solve_simplex_qp(b, Sigma, lam, budget)
        f = lambda x: -(b @ x - 0.5 * lam * x @ Sigma @ x)
        jac = lambda x: -(b - lam * Sigma @ x)
        ref = minimize(f, np.ones(d) * budget / (d + 1), jac=jac,
                       bounds=[(0, budget)] * d,
                       constraints=[{'type': 'ineq', 'fun': lambda x: budget - x.sum(),
                                     'jac': lambda x: -np.ones(d)}],
                       method='SLSQP', options={'ftol': 1e-12, 'maxiter': 1000})
        if not ref.success:
            continue
        val = lambda x: b @ x - 0.5 * lam * x @ Sigma @ x
        max_gap = max(max_gap, abs(val(pi) - val(ref.x)))
        max_violation = max(max_violation, max(0.0, -float(pi.min()), float(pi.sum() - budget)))
        checked += 1
    print({'requested_cases': args.cases, 'checked_cases': checked,
           'max_objective_gap_vs_slsqp': max_gap,
           'max_constraint_violation': max_violation})
    if checked < args.cases or max_gap > 1e-7 or max_violation > 1e-7:
        raise SystemExit('Validation did not meet the requested tolerance')


if __name__ == '__main__':
    main()
