import json, sys, collections, numpy as np
rows = [json.loads(l) for l in open(sys.argv[1])]
g = collections.defaultdict(list)
for r in rows: g[(r["problem"], r["method"])].append(r)
print(f"{'prob':4} {'meth':4} {'n':>2} {'params':>6} {'V relL2':>10} {'pi rmse':>9} {'viol':>6} {'FB err':>8} {'time s':>7}")
for (pr, m), rs in sorted(g.items()):
    f = lambda k: np.nanmean([r[k] for r in rs])
    print(f"{pr:4} {m:4} {len(rs):>2} {rs[0]['n_params']:>6} {f('V_rel_l2'):>10.3e} {f('pi_rmse'):>9.3e} {f('raw_violation_frac'):>6.2f} {f('free_boundary_err'):>8.3f} {f('train_time'):>7.1f}")
