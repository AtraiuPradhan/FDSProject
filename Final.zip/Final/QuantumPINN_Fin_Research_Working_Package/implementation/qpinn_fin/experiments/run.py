"""Run one or many (problem, method, seed) jobs; append JSON lines to results file.
usage: python -m experiments.run --problems P0 P1 --methods B1 B2 B3 B4 B5 --seeds 0 1 2 --steps 2000 --out results/pilot.jsonl
"""
import argparse, json, os, time
from qpinn_fin.config import PRIMARY, problem_params
from qpinn_fin.trainer import train
from qpinn_fin.evaluate import evaluate

ap = argparse.ArgumentParser()
ap.add_argument("--problems", nargs="+", default=["P0", "P1"])
ap.add_argument("--methods", nargs="+", default=["B1", "B2", "B3", "B4", "B5"])
ap.add_argument("--seeds", nargs="+", type=int, default=[0])
ap.add_argument("--steps", type=int, default=2000)
ap.add_argument("--lr", type=float, default=1e-2)
ap.add_argument("--out", default="results/pilot.jsonl")
a = ap.parse_args()
os.makedirs(os.path.dirname(a.out), exist_ok=True)
for prob in a.problems:
    p = problem_params(prob, PRIMARY)
    for m in a.methods:
        for s in a.seeds:
            model, info = train(m, p, s, steps=a.steps, lr=a.lr)
            ev = evaluate(model, p)
            rec = dict(problem=prob, method=m, seed=s, steps=a.steps, n_params=info["n_params"],
                       train_time=info["train_time"], final_pde=info["history"][-1][1], **ev)
            print(json.dumps(rec), flush=True)
            with open(a.out, "a") as f:
                f.write(json.dumps(rec) + "\n")
