"""Exact active-set solver for the small constrained Merton Hamiltonian QP.

Solve
    max_pi b^T pi - 0.5 * lam * pi^T Sigma pi
    subject to pi_i >= 0 and sum(pi) <= budget,
where Sigma is symmetric positive definite and lam > 0.

This is a numerical primitive for the proposed multi-asset extension. It is
not yet integrated into the training loop or the finite-difference reference.
"""
from __future__ import annotations

from itertools import combinations
import numpy as np


def solve_simplex_qp(b, Sigma, lam: float, budget: float = 1.0, tol: float = 1e-9) -> np.ndarray:
    """Return the optimizer for a concave quadratic over a nonnegative capped simplex.

    Parameters
    ----------
    b : array-like, shape (d,)
        Excess-return vector multiplied by the positive value derivative factor.
    Sigma : array-like, shape (d,d)
        Symmetric positive-definite covariance matrix.
    lam : float
        Positive curvature ratio. Must be strictly positive.
    budget : float
        Upper bound on the sum of risky weights; must be nonnegative.
    tol : float
        Numerical tolerance for KKT feasibility checks.

    Notes
    -----
    Enumerates every nonempty positive support and both possible states of the
    budget constraint (inactive/active). For the intended small dimension
    (e.g. three risky assets), this is inexpensive and avoids a black-box QP
    dependency. The returned solution is checked against primal and KKT
    conditions; failure raises RuntimeError rather than silently returning a
    potentially infeasible policy.
    """
    b = np.asarray(b, dtype=float).reshape(-1)
    Sigma = np.asarray(Sigma, dtype=float)
    d = b.size
    if Sigma.shape != (d, d):
        raise ValueError("Sigma must have shape (len(b), len(b))")
    if not np.all(np.isfinite(b)) or not np.all(np.isfinite(Sigma)):
        raise ValueError("b and Sigma must be finite")
    if lam <= 0 or not np.isfinite(lam):
        raise ValueError("lam must be finite and strictly positive")
    if budget < 0 or not np.isfinite(budget):
        raise ValueError("budget must be finite and nonnegative")
    if not np.allclose(Sigma, Sigma.T, atol=1e-10, rtol=1e-10):
        raise ValueError("Sigma must be symmetric")
    if np.linalg.eigvalsh(Sigma).min() <= 0:
        raise ValueError("Sigma must be positive definite")
    if budget == 0:
        return np.zeros(d, dtype=float)

    best = None
    best_obj = -np.inf
    all_idx = tuple(range(d))

    # KKT candidate with all risky weights zero.
    if np.all(b <= tol):
        best = np.zeros(d, dtype=float)
        best_obj = 0.0

    for size in range(1, d + 1):
        for support in combinations(all_idx, size):
            idx = np.asarray(support, dtype=int)
            S = Sigma[np.ix_(idx, idx)]
            bs = b[idx]
            inv_b = np.linalg.solve(S, bs)
            inv_1 = np.linalg.solve(S, np.ones(size))

            # Case 1: sum constraint inactive (its KKT multiplier is zero).
            pi_s = inv_b / lam
            cand = np.zeros(d, dtype=float)
            cand[idx] = pi_s
            if np.all(pi_s > tol) and cand.sum() <= budget + tol:
                grad = b - lam * (Sigma @ cand)
                excluded = [j for j in all_idx if j not in support]
                if all(grad[j] <= tol for j in excluded):
                    obj = float(b @ cand - 0.5 * lam * cand @ Sigma @ cand)
                    if obj > best_obj:
                        best, best_obj = cand, obj

            # Case 2: sum constraint active; multiplier nu must be nonnegative.
            denom = float(np.ones(size) @ inv_1)
            nu = float((np.ones(size) @ inv_b - lam * budget) / denom)
            pi_s = (inv_b - nu * inv_1) / lam
            cand = np.zeros(d, dtype=float)
            cand[idx] = pi_s
            if np.all(pi_s > tol) and nu >= -tol and abs(cand.sum() - budget) <= 1e-7:
                grad = b - lam * (Sigma @ cand) - nu * np.ones(d)
                excluded = [j for j in all_idx if j not in support]
                if all(grad[j] <= tol for j in excluded):
                    obj = float(b @ cand - 0.5 * lam * cand @ Sigma @ cand)
                    if obj > best_obj:
                        best, best_obj = cand, obj

    if best is None:
        raise RuntimeError("No KKT-feasible active-set candidate found; inspect conditioning/tolerance")
    if best.min() < -1e-7 or best.sum() > budget + 1e-7:
        raise RuntimeError("Internal error: returned policy violates constraints")
    return np.maximum(best, 0.0)
