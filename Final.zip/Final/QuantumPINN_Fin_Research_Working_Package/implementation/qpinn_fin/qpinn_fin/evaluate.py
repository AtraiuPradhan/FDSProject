"""Evaluation against the reference (closed form for P0, finite differences for P1)."""
from __future__ import annotations

import numpy as np
import torch

from .config import Params
from .hjb import derivs, policy_raw
from .reference import load_or_solve_fd, p0_closed_form

C_LO, C_HI = 0.1, 10.0  # evaluation window, away from the truncation edges


def _model_fields(model, p, c, t):
    ct = torch.tensor(c)
    tt = torch.full_like(ct, float(t))
    V, V_t, V_c, V_cc, cl, tl = derivs(model, ct, tt, create_graph=False)
    raw = policy_raw(V_c, V_cc, cl, tl, p)
    return V.detach().numpy(), raw.detach().numpy()


def evaluate(model, p: Params, n_c: int = 400, free_thresh: float = 0.99):
    c = np.exp(np.linspace(np.log(C_LO), np.log(C_HI), n_c))
    out = {}
    if p.F == 0:
        errs_V, errs_pi, viol = [], [], []
        for t in np.linspace(0, p.T, 11)[:-1]:
            Vm, raw = _model_fields(model, p, c, t)
            Vr, pir = p0_closed_form(c, t, p)
            errs_V.append(np.sqrt(np.mean(((Vm - Vr) / np.abs(Vr)) ** 2)))
            errs_pi.append(np.sqrt(np.mean((np.clip(raw, 0, 1) - pir) ** 2)))
            viol.append(np.mean((raw > 1 + 1e-2) | (raw < -1e-2)))
        out.update(V_rel_l2=float(np.mean(errs_V)), pi_rmse=float(np.mean(errs_pi)),
                   raw_violation_frac=float(np.mean(viol)), free_boundary_err=float("nan"))
        return out
    sol = load_or_solve_fd(p)
    errs_V, errs_pi, viol, fb = [], [], [], []
    for i, t in enumerate(sol.t[:-1]):  # skip t = T (V_cc singular there for trial form is fine, but pi undefined)
        Vm, raw = _model_fields(model, p, c, t)
        Vr, pir = sol.interp(i, c)
        errs_V.append(np.sqrt(np.mean(((Vm - Vr) / np.abs(Vr)) ** 2)))
        errs_pi.append(np.sqrt(np.mean((np.clip(raw, 0, 1) - pir) ** 2)))
        viol.append(np.mean((raw > 1 + 1e-2) | (raw < -1e-2)))
        # free boundary: smallest cushion where clipped policy reaches free_thresh
        pm = np.clip(raw, 0, 1)
        j = np.argmax(pm >= free_thresh)
        fb_m = c[j] if pm[j] >= free_thresh else float("nan")
        pr = pir
        k = np.argmax(pr >= free_thresh)
        fb_r = c[k] if pr[k] >= free_thresh else float("nan")
        if not (np.isnan(fb_m) or np.isnan(fb_r)):
            fb.append(abs(np.log(fb_m / fb_r)))
    out.update(V_rel_l2=float(np.mean(errs_V)), pi_rmse=float(np.mean(errs_pi)),
               raw_violation_frac=float(np.mean(viol)),
               free_boundary_err=float(np.mean(fb)) if fb else float("nan"))
    return out
