"""HJB residuals in cushion coordinates c = w - F exp(-r (T-t)).

    V_t + r c V_c + max_{pi in [0,1]} { (mu-r) w pi V_c + 0.5 sigma^2 w^2 pi^2 V_cc } = 0,   w = c + F exp(-r(T-t))

Three policy readings are provided; training variants differ ONLY in how the policy enters the residual:
  * constraint-consistent ("cc"):  pi = clip(pi_raw, 0, 1), read from V's own derivatives
  * penalty ("pen")             :  pi = pi_raw (unconstrained maximiser), plus a penalty on |pi_raw outside [0,1]|
The policy is detached inside the residual (envelope theorem / Danskin: the gradient is identical with or
without detach; tests/test_hjb.py checks this. Detach is a convenience, NOT a speed-up).
"""
from __future__ import annotations

import torch

from .config import Params


def wealth(c, t, p: Params):
    return c + p.F * torch.exp(-p.r * (p.T - t))


def policy_raw(V_c, V_cc, c, t, p: Params):
    """Unconstrained maximiser. V_cc is clamped to <= -eps (training safeguard, not part of the math).
    NB: torch.minimum(V_cc, -eps) fails with a float eps; clamp(max=) is the correct call."""
    w = wealth(c, t, p)
    return -(p.mu - p.r) * V_c / (p.sigma ** 2 * w * V_cc.clamp(max=-p.eps))


def policy_clip(V_c, V_cc, c, t, p: Params):
    return policy_raw(V_c, V_cc, c, t, p).clamp(0.0, 1.0)


def residual(V_t, V_c, V_cc, c, t, p: Params, mode: str = "cc", detach: bool = True):
    """HJB residual for given derivatives. mode in {"cc", "pen"}. Returns (residual, pi_raw)."""
    w = wealth(c, t, p)
    raw = policy_raw(V_c, V_cc, c, t, p)
    pi = raw.clamp(0.0, 1.0) if mode == "cc" else raw
    if detach:
        pi = pi.detach()
    R = V_t + p.r * c * V_c + (p.mu - p.r) * w * pi * V_c + 0.5 * p.sigma ** 2 * w ** 2 * pi ** 2 * V_cc
    return R, raw


def derivs(model, c, t, create_graph=True):
    """V, V_t (at fixed c), V_c, V_cc via autograd. c, t are fresh leaves."""
    c = c.detach().clone().requires_grad_(True)
    t = t.detach().clone().requires_grad_(True)
    V = model.V(c, t)
    V_c, V_t = torch.autograd.grad(V.sum(), (c, t), create_graph=True)
    V_cc, = torch.autograd.grad(V_c.sum(), c, create_graph=create_graph)
    return V, V_t, V_c, V_cc, c, t
