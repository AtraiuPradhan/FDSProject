"""Problem parameters for the constrained Merton HJB study.

One code path serves both test problems:
  P0: F = 0   -> cushion c equals wealth w; box constraint pi in [0, 1] only.
  P1: F > 0   -> terminal floor F*exp(-r(T-t)); cushion c = w - floor; pi in [0, 1]
                 (no leverage) makes the exposure cap A <= w, giving a free boundary.

Parameter sets
  PRIMARY: gamma = 2 (realistic risk aversion). Unconstrained Merton fraction is
           (mu-r)/(gamma sigma^2) = 1.556 > 1, so the leverage cap binds.
  SANITY : gamma = 0.5 (Merton fraction 2.5), kept as a second regime.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
import math


@dataclass(frozen=True)
class Params:
    mu: float = 0.10
    r: float = 0.03
    sigma: float = 0.15
    gamma: float = 2.0
    T: float = 1.0
    F: float = 0.3            # terminal wealth floor (0 => problem P0)
    cmin: float = 0.05        # truncated cushion domain [cmin, cmax]
    cmax: float = 20.0
    eps: float = 1e-8         # training safeguard on V_cc (NOT part of the math)

    # ---- derived quantities -------------------------------------------------
    @property
    def merton_fraction(self) -> float:
        return (self.mu - self.r) / (self.gamma * self.sigma ** 2)

    def kappa(self, pi: float) -> float:
        """Growth-rate constant for a constant risky fraction pi."""
        return self.r + pi * (self.mu - self.r) - 0.5 * self.gamma * self.sigma ** 2 * pi ** 2

    @property
    def s_unc(self) -> float:
        """Exponent S of the closed-form solution when the cap is inactive (cushion Merton)."""
        return (1.0 - self.gamma) * self.kappa(self.merton_fraction)

    @property
    def s_cap(self) -> float:
        """Exponent S when the policy is pinned at pi = 1 (cap always binding)."""
        return (1.0 - self.gamma) * self.kappa(1.0)

    @property
    def s_p0(self) -> float:
        """Exponent S of the P0 closed form: pi* = clip(merton_fraction, 0, 1)."""
        return (1.0 - self.gamma) * self.kappa(min(max(self.merton_fraction, 0.0), 1.0))

    def with_floor(self, F: float) -> "Params":
        return replace(self, F=F)

    def key(self) -> str:
        return "_".join(f"{v:g}" for v in (self.mu, self.r, self.sigma, self.gamma, self.T,
                                           self.F, self.cmin, self.cmax))


PRIMARY = Params()
SANITY = Params(mu=0.08, r=0.03, sigma=0.20, gamma=0.5, F=0.3)


def problem_params(problem: str, base: Params = PRIMARY) -> Params:
    """P0 -> F = 0, P1 -> F > 0 (as set in `base`)."""
    if problem.upper() == "P0":
        return base.with_floor(0.0)
    if problem.upper() == "P1":
        if base.F <= 0:
            raise ValueError("P1 needs F > 0")
        return base
    raise ValueError(f"unknown problem {problem}")


def utility_scale(c: float, gamma: float) -> float:
    return c ** (1.0 - gamma) / (1.0 - gamma)


assert math.isclose(PRIMARY.merton_fraction, 0.07 / (2 * 0.0225))
