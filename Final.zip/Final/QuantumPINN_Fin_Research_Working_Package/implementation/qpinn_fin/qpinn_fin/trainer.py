"""Training loop. Methods:
  B1 mlp+pen   B2 mlp+cc   B3 noent+cc   B4 quantum+pen   B5 quantum+cc
"""
from __future__ import annotations

import math
import time

import numpy as np
import torch

from .config import Params
from .hjb import derivs, residual
from .models import build

METHODS = {
    "B1": ("mlp", "pen"), "B2": ("mlp", "cc"), "B3": ("noent", "cc"),
    "B4": ("quantum", "pen"), "B5": ("quantum", "cc"),
}


def boundary_exponents(p: Params):
    """Asymptotic exponents at the lower/upper cushion boundaries.

    P0 uses the constrained constant Merton fraction at both boundaries.
    For P1, the floor makes the risky fraction tend to max(pi_M, 0) as c -> 0,
    while as c -> infinity it tends to clip(pi_M, 0, 1). This distinction matters
    when rolling historical estimates imply a negative or sub-unit Merton fraction.
    """
    if p.F == 0:
        return (p.s_p0, p.s_p0)
    pi_m = p.merton_fraction
    pi_lo = max(pi_m, 0.0)
    pi_hi = min(max(pi_m, 0.0), 1.0)
    s_lo = (1.0 - p.gamma) * p.kappa(pi_lo)
    s_hi = (1.0 - p.gamma) * p.kappa(pi_hi)
    return (s_lo, s_hi)


def sample(n, p: Params, gen):
    lc = math.log(p.cmin) + (math.log(p.cmax) - math.log(p.cmin)) * torch.rand(n, generator=gen)
    t = p.T * torch.rand(n, generator=gen)
    return torch.exp(lc), t


def train(method: str, p: Params, seed: int, steps: int = 2000, n_int: int = 256, n_bd: int = 32,
          lr: float = 1e-2, lam_pen: float = 1.0, lam_bd: float = 1.0, log_every: int = 200,
          n_qubits: int = 4, layers: int = 4, verbose: bool = False):
    arch, mode = METHODS[method]
    torch.manual_seed(seed)
    gen = torch.Generator().manual_seed(seed + 12345)
    exps = boundary_exponents(p)
    model = build(arch, p, exps, n_qubits, layers)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.1 ** (1.0 / steps))
    s_lo, s_hi = exps
    hist, t0 = [], time.time()
    for k in range(steps):
        c, t = sample(n_int, p, gen)
        V, V_t, V_c, V_cc, cl, tl = derivs(model, c, t)
        R, raw = residual(V_t, V_c, V_cc, cl, tl, p, mode=mode)
        u = (cl ** (1 - p.gamma) / (1 - p.gamma)).abs()
        loss_pde = ((R / u) ** 2).mean()
        # boundary: S pinned at the truncation edges
        tb = p.T * torch.rand(n_bd, generator=gen)
        S_lo = model.S(torch.full_like(tb, p.cmin), tb)
        S_hi = model.S(torch.full_like(tb, p.cmax), tb)
        loss_bd = ((S_lo - s_lo) ** 2).mean() + ((S_hi - s_hi) ** 2).mean()
        loss = loss_pde + lam_bd * loss_bd
        if mode == "pen":
            viol = torch.relu(raw - 1.0) ** 2 + torch.relu(-raw) ** 2
            loss = loss + lam_pen * viol.mean()
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
        opt.step(); sched.step()
        if k % log_every == 0 or k == steps - 1:
            hist.append((k, loss_pde.item(), loss_bd.item(), time.time() - t0))
            if verbose:
                print(f"{method} seed{seed} step{k} pde={float(loss_pde):.3e} bd={float(loss_bd):.3e}")
    return model, {"history": hist, "train_time": time.time() - t0, "n_params": model.n_params()}
