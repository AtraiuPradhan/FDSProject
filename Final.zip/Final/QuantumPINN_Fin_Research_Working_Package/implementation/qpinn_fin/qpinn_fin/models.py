"""Models. All share the trial form  V(c,t) = u(c) exp((T-t) S(x, tau)),  u(c) = c^(1-g)/(1-g),
which hard-enforces V(c,T) = u(c) and the c -> 0 behaviour. Only the network S differs:

  MLPS      classical MLP                                  (B1, B2)
  QuantumS  statevector circuit, data re-uploading         (B3 entangler='none', B4, B5 entangler='ring')

S is squashed to  s_mid + s_half * tanh(.)  with a window around the two known exponents (identical for every
model, so no model is advantaged). NOTE: the quantum circuit is a Fourier/re-uploading STAND-IN for the tensor-rank
polynomial circuit of Wang et al. (arXiv 2604.03346), whose exact circuit is not reproduced here.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn

from .config import Params

torch.set_default_dtype(torch.float64)


class Base(nn.Module):
    def __init__(self, p: Params, problem_exponents):
        super().__init__()
        self.p = p
        lo, hi = problem_exponents
        self.s_mid = 0.5 * (lo + hi)
        self.s_half = 3.0 * abs(hi - lo) + 0.05
        self.lc0, self.lc1 = math.log(p.cmin), math.log(p.cmax)

    def feats(self, c, t):
        xn = 2 * (torch.log(c) - self.lc0) / (self.lc1 - self.lc0) - 1
        tn = (self.p.T - t) / self.p.T
        return xn, tn

    def raw(self, xn, tn):  # -> (B,)
        raise NotImplementedError

    def S(self, c, t):
        xn, tn = self.feats(c, t)
        return self.s_mid + self.s_half * torch.tanh(self.raw(xn, tn))

    def V(self, c, t):
        g = self.p.gamma
        u = c ** (1 - g) / (1 - g)
        return u * torch.exp((self.p.T - t) * self.S(c, t))

    def n_params(self):
        return sum(q.numel() for q in self.parameters())


class MLPS(Base):
    def __init__(self, p, exps, hidden=8, layers=2):
        super().__init__(p, exps)
        dims = [2] + [hidden] * layers + [1]
        mods = []
        for i in range(len(dims) - 1):
            mods.append(nn.Linear(dims[i], dims[i + 1]))
            if i < len(dims) - 2:
                mods.append(nn.Tanh())
        self.net = nn.Sequential(*mods)
        nn.init.zeros_(self.net[-1].bias)
        self.net[-1].weight.data *= 0.1

    def raw(self, xn, tn):
        return self.net(torch.stack([xn, tn], -1)).squeeze(-1)


def mlp_for_budget(p, exps, budget, layers=2):
    """Hidden width whose parameter count is closest to the quantum circuit's."""
    best = None
    for h in range(2, 64):
        m = MLPS(p, exps, hidden=h, layers=layers)
        d = abs(m.n_params() - budget)
        if best is None or d < best[0]:
            best = (d, h)
    return MLPS(p, exps, hidden=best[1], layers=layers)


# --------------------------------------------------------------------------- statevector circuit
def _ry(theta):  # (...,) -> (...,2,2) complex
    c, s = torch.cos(theta / 2), torch.sin(theta / 2)
    return torch.stack([torch.stack([c, -s], -1), torch.stack([s, c], -1)], -2).to(torch.complex128)


def _rz(theta):
    e = torch.exp(-0.5j * theta.to(torch.complex128))
    z = torch.zeros_like(e)
    return torch.stack([torch.stack([e, z], -1), torch.stack([z, e.conj()], -1)], -2)


def apply_1q(state, U, q, n):
    """state (B,2^n) complex; U (2,2) or (B,2,2); apply on qubit q (0 = most significant)."""
    B = state.shape[0]
    s = state.reshape(B, *([2] * n)).movedim(q + 1, 1).reshape(B, 2, -1)
    s = torch.matmul(U, s)
    return s.reshape(B, 2, *([2] * (n - 1))).movedim(1, q + 1).reshape(B, -1)


def zz_sign(n, pairs):
    """Diagonal of prod_{(i,j)} CZ(i,j): (-1)^{b_i b_j}."""
    idx = torch.arange(2 ** n)
    bits = [(idx >> (n - 1 - q)) & 1 for q in range(n)]
    ph = torch.zeros(2 ** n, dtype=torch.long)
    for i, j in pairs:
        ph = ph + bits[i] * bits[j]
    return (1 - 2 * (ph % 2)).to(torch.complex128)


def z_matrix(n):
    idx = torch.arange(2 ** n)
    return torch.stack([1.0 - 2.0 * ((idx >> (n - 1 - q)) & 1).double() for q in range(n)], -1)  # (2^n, n)


def ring_pairs(n):
    return [(i, (i + 1) % n) for i in range(n)] if n > 2 else [(0, 1)]


class QuantumS(Base):
    def __init__(self, p, exps, n_qubits=4, layers=4, entangler="ring", pairs=None, seed_scale=0.1):
        super().__init__(p, exps)
        self.n, self.L = n_qubits, layers
        if entangler == "none":
            pairs = []
        elif pairs is None:
            pairs = ring_pairs(n_qubits)
        self.pairs = pairs
        self.register_buffer("sign", zz_sign(n_qubits, pairs))
        self.register_buffer("Z", z_matrix(n_qubits))
        self.theta = nn.Parameter(torch.randn(layers, n_qubits, 3) * 1.0)
        self.readout = nn.Parameter(torch.randn(n_qubits) * seed_scale)
        self.bias = nn.Parameter(torch.zeros(()))
        # qubit q uploads feature (x, tau, x, tau, ...) with multiplier 1 or 2 (spectrum growth)
        self.mult = [1.0 if q < 2 else 2.0 for q in range(n_qubits)]
        self.base = 1.5

    def raw(self, xn, tn):
        B, n = xn.shape[0], self.n
        state = torch.zeros(B, 2 ** n, dtype=torch.complex128, device=xn.device)
        state[:, 0] = 1.0
        for l in range(self.L):
            for q in range(n):
                f = xn if q % 2 == 0 else tn
                state = apply_1q(state, _ry(self.base * self.mult[q] * f), q, n)
            for q in range(n):
                th = self.theta[l, q]
                U = _rz(th[0]) @ _ry(th[1]) @ _rz(th[2])
                state = apply_1q(state, U, q, n)
            if self.pairs:
                state = state * self.sign
        probs = state.real ** 2 + state.imag ** 2
        z = probs @ self.Z  # (B, n)
        return z @ self.readout + self.bias


def build(name: str, p: Params, exps, n_qubits=4, layers=4):
    """name in {mlp, quantum, noent}; MLP is parameter-matched to the ring circuit."""
    if name == "mlp":
        q = QuantumS(p, exps, n_qubits, layers, "ring")
        return mlp_for_budget(p, exps, q.n_params())
    if name == "quantum":
        return QuantumS(p, exps, n_qubits, layers, "ring")
    if name == "noent":
        return QuantumS(p, exps, n_qubits, layers, "none")
    raise ValueError(name)
