"""Reference (ground-truth) solutions.

P0 (F = 0)  : closed form, V = exp(S (T-t)) c^(1-g)/(1-g) with S = (1-g) kappa(pi*), pi* = clip(Merton, 0, 1).
P1 (F > 0)  : finite-difference solver on a log-cushion grid (no closed form once the cap binds).
              With the cap removed it must reproduce the closed form with S = s_unc; the tests check this.
              With the cap enabled, asymptotic boundary exponents depend on whether the rolling
              Merton fraction is below zero, inside [0,1], or above one.

The FD scheme (explicit in time, log-cushion x = ln c):
    V_t + r V_x + max_q { q (mu-r) V_x + 0.5 q^2 sigma^2 (V_xx - V_x) } = 0,
    q = A / c (risky amount / cushion), constraint A <= w  <=>  q <= 1 + F e^{-r(T-t)} / c,  q >= 0.
Boundary values at c = cmin / cmax come from constrained closed-form asymptotics. The low-cushion
limit permits a positive unconstrained cushion fraction but respects the lower bound; the high-cushion
limit uses the [0,1]-clipped Merton fraction. This is important for rolling historical estimates.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib

import numpy as np

from .config import Params

CACHE = Path(__file__).resolve().parent.parent / "reference_cache"


# --------------------------------------------------------------------------- closed forms
def u_of_c(c, p: Params):
    return c ** (1.0 - p.gamma) / (1.0 - p.gamma)


def closed_form_V(c, t, p: Params, S: float):
    """V = u(c) exp(S (T - t)) for a constant exponent S."""
    return u_of_c(c, p) * np.exp(S * (p.T - t))


def p0_closed_form(c, t, p: Params):
    """P0 (F = 0): value, policy."""
    S = p.s_p0
    pi = min(max(p.merton_fraction, 0.0), 1.0)
    return closed_form_V(c, t, p, S), np.full_like(np.asarray(c, dtype=float), pi)


# --------------------------------------------------------------------------- finite differences
@dataclass
class FDSolution:
    c: np.ndarray            # (Nx+1,) cushion grid
    x: np.ndarray            # log grid
    t: np.ndarray            # (Ns,) saved times, increasing
    V: np.ndarray            # (Ns, Nx+1)
    pi: np.ndarray           # (Ns, Nx+1) risky fraction of wealth, pi = q c / w
    dx: float
    p: Params

    def at(self, t_index: int):
        return self.V[t_index], self.pi[t_index]

    def interp(self, t_index: int, c_query):
        xq = np.log(np.asarray(c_query, dtype=float))
        return (np.interp(xq, self.x, self.V[t_index]), np.interp(xq, self.x, self.pi[t_index]))

    def free_boundary(self, t_index: int, thresh: float = 0.999) -> float:
        """Smallest cushion at which the leverage cap binds (pi >= thresh), linear interpolation."""
        pi = self.pi[t_index]
        idx = np.argmax(pi >= thresh)
        if pi[idx] < thresh:
            return float("nan")
        if idx == 0:
            return float(self.c[0])
        x0, x1, p0, p1 = self.x[idx - 1], self.x[idx], pi[idx - 1], pi[idx]
        xs = x0 + (thresh - p0) * (x1 - x0) / (p1 - p0)
        return float(np.exp(xs))


def solve_fd(p: Params, cap: bool = True, Nx: int = 500, Nt: int = 60000, n_save: int = 20) -> FDSolution:
    x = np.linspace(np.log(p.cmin), np.log(p.cmax), Nx + 1)
    dx = x[1] - x[0]
    c = np.exp(x)
    dt = p.T / Nt
    mu, r, sig, gam, T, F = p.mu, p.r, p.sigma, p.gamma, p.T, p.F
    # explicit-scheme stability: dt <= dx^2 / (q_max^2 sigma^2)
    q_max = 1.0 + F / p.cmin
    if dt > 0.9 * dx ** 2 / (q_max ** 2 * sig ** 2):
        raise ValueError("FD time step too large for stability; increase Nt")
    if cap:
        # Regime-aware constrained asymptotics for historical rolling estimates:
        # c -> 0: lower constraint may bind, but the upper cap is asymptotically inactive;
        # c -> infinity: both floor effects vanish and the [0,1] Merton clip applies.
        pi_m = p.merton_fraction
        pi_lo = max(pi_m, 0.0)
        pi_hi = min(max(pi_m, 0.0), 1.0)
        s_lo = (1.0 - gam) * (r + pi_lo * (mu - r) - 0.5 * gam * sig ** 2 * pi_lo ** 2)
        s_hi = (1.0 - gam) * (r + pi_hi * (mu - r) - 0.5 * gam * sig ** 2 * pi_hi ** 2)
    else:
        s_lo = p.s_unc
        s_hi = p.s_unc
    V = c ** (1 - gam) / (1 - gam)
    save_every = Nt // n_save
    ts, Vs, pis = [T], [V.copy()], []
    Vx = np.zeros_like(V); Vxx = np.zeros_like(V)

    def policy_and_H(V, t):
        Vx[1:-1] = (V[2:] - V[:-2]) / (2 * dx)
        Vxx[1:-1] = (V[2:] - 2 * V[1:-1] + V[:-2]) / dx ** 2
        D = np.minimum(Vxx - Vx, -1e-12)
        q = np.maximum(-(mu - r) * Vx / (sig ** 2 * D), 0.0)
        floor = F * np.exp(-r * (T - t))
        if cap:
            q = np.minimum(q, 1.0 + floor / c)
        H = r * Vx + q * (mu - r) * Vx + 0.5 * q ** 2 * sig ** 2 * D
        w = c + floor
        return q * c / w, H

    pi0, _ = policy_and_H(V, T)
    pis.append(pi0)
    for k in range(Nt):
        t = T - k * dt
        _, H = policy_and_H(V, t)
        V = V + dt * H
        tn = t - dt
        V[0] = np.exp(s_lo * (T - tn)) * c[0] ** (1 - gam) / (1 - gam)
        V[-1] = np.exp(s_hi * (T - tn)) * c[-1] ** (1 - gam) / (1 - gam)
        if (k + 1) % save_every == 0:
            pi_k, _ = policy_and_H(V, tn)
            ts.append(tn); Vs.append(V.copy()); pis.append(pi_k)
    # first saved V pairs with pi at T; align lengths
    ts = np.array(ts[::-1]); Vs = np.array(Vs[::-1]); pis = np.array(pis[::-1])
    return FDSolution(c=c, x=x, t=ts, V=Vs, pi=pis, dx=dx, p=p)


def load_or_solve_fd(p: Params, cap: bool = True, **kw) -> FDSolution:
    tag = hashlib.md5((p.key() + f"_{cap}_" + str(sorted(kw.items()))).encode()).hexdigest()[:10]
    path = CACHE / f"fd_{tag}.npz"
    if path.exists():
        d = np.load(path)
        return FDSolution(c=d["c"], x=d["x"], t=d["t"], V=d["V"], pi=d["pi"], dx=float(d["dx"]), p=p)
    sol = solve_fd(p, cap=cap, **kw)
    CACHE.mkdir(exist_ok=True)
    np.savez(path, c=sol.c, x=sol.x, t=sol.t, V=sol.V, pi=sol.pi, dx=sol.dx)
    return sol
