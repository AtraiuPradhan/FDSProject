import numpy as np, torch, pytest
from qpinn_fin.config import PRIMARY, SANITY, problem_params
from qpinn_fin.hjb import residual, derivs, policy_raw
from qpinn_fin.models import QuantumS, MLPS, apply_1q, _ry, _rz
from qpinn_fin.reference import solve_fd, p0_closed_form
from qpinn_fin.trainer import boundary_exponents

class ExactP0:
    """Closed-form P0 value as a model object (for the residual test)."""
    def __init__(s, p): s.p = p
    def V(s, c, t):
        g = s.p.gamma
        return c ** (1 - g) / (1 - g) * torch.exp(s.p.s_p0 * (s.p.T - t))

@pytest.mark.parametrize("base", [PRIMARY, SANITY])
def test_closed_form_residual_zero(base):
    p = problem_params("P0", base)
    c = torch.exp(torch.linspace(-2, 2, 50)); t = torch.linspace(0, 0.9, 50)
    V, Vt, Vc, Vcc, cl, tl = derivs(ExactP0(p), c, t)
    R, _ = residual(Vt, Vc, Vcc, cl, tl, p, "cc")
    assert (R / V.abs()).abs().max() < 1e-9

def test_detach_same_gradient():
    p = problem_params("P1")
    torch.manual_seed(0)
    m = QuantumS(p, boundary_exponents(p))
    c = torch.exp(torch.linspace(-2, 2, 40)); t = torch.linspace(0, 0.9, 40)
    gs = []
    for det in (True, False):
        m.zero_grad()
        V, Vt, Vc, Vcc, cl, tl = derivs(m, c, t)
        R, _ = residual(Vt, Vc, Vcc, cl, tl, p, "cc", detach=det)
        (R ** 2).mean().backward()
        gs.append(torch.cat([q.grad.flatten() for q in m.parameters()]))
    # Danskin/envelope: for the clipped policy the detached and attached gradients coincide
    assert (gs[0]-gs[1]).norm() / gs[0].norm() < 1e-10

def test_double_backward_finite():
    p = problem_params("P1")
    for m in (QuantumS(p, boundary_exponents(p)), MLPS(p, boundary_exponents(p))):
        c = torch.exp(torch.linspace(-2, 2, 20)); t = torch.linspace(0, 0.9, 20)
        V, Vt, Vc, Vcc, cl, tl = derivs(m, c, t)
        R, _ = residual(Vt, Vc, Vcc, cl, tl, p)
        (R ** 2).mean().backward()
        assert all(torch.isfinite(q.grad).all() for q in m.parameters())

def test_clamp_not_minimum():
    p = problem_params("P1")
    out = policy_raw(torch.tensor([1.0]), torch.tensor([0.5]), torch.tensor([1.0]), torch.tensor([0.0]), p)
    assert torch.isfinite(out).all()

def test_fd_matches_closed_form_cap_off():
    p = problem_params("P1", SANITY)
    sol = solve_fd(p.with_floor(0.0) if False else p, cap=False, Nx=300, Nt=40000, n_save=4)
    # with the cap off, floor only shifts w; closed form in cushion coords is exact: V = u(c) exp(s_unc (T-t))
    from qpinn_fin.reference import closed_form_V
    c = sol.c; mid = (c > 0.2) & (c < 8)
    V0 = closed_form_V(c, sol.t[0], p, p.s_unc)
    err = np.max(np.abs(sol.V[0][mid] / V0[mid] - 1))
    assert err < 5e-3, err

def test_statevector_vs_pennylane():
    import pennylane as qml
    n = 3
    dev = qml.device("default.qubit", wires=n)
    th = np.random.RandomState(0).randn(n, 3)
    @qml.qnode(dev)
    def circ():
        for q in range(n): qml.RZ(th[q, 0], wires=q); qml.RY(th[q, 1], wires=q); qml.RZ(th[q, 2], wires=q)
        qml.CZ(wires=[0, 1]); qml.CZ(wires=[1, 2])
        return qml.state()
    ref = circ()
    from qpinn_fin.models import zz_sign
    s = torch.zeros(1, 8, dtype=torch.complex128); s[0, 0] = 1
    for q in range(n):
        thq = torch.tensor(th[q])
        U = _rz(thq[2]) @ _ry(thq[1]) @ _rz(thq[0])  # RZ(th0) applied first -> rightmost
        s = apply_1q(s, U, q, n)
    s = s * zz_sign(n, [(0, 1), (1, 2)])
    # global phase tolerant comparison
    ov = np.abs(np.vdot(ref, s[0].numpy()))
    assert abs(ov - 1) < 1e-10
