import numpy as np
from qpinn_fin.multasset_qp import solve_simplex_qp


def objective(pi, b, S, lam):
    return float(b @ pi - 0.5 * lam * pi @ S @ pi)


def test_symmetric_assets_split_equally_when_budget_binds():
    b = np.array([0.2, 0.2, 0.2])
    S = np.eye(3)
    pi = solve_simplex_qp(b, S, lam=0.1, budget=1.0)
    assert np.all(pi >= -1e-10)
    assert abs(pi.sum() - 1.0) < 1e-8
    assert np.allclose(pi, np.ones(3) / 3, atol=1e-8)


def test_inactive_budget_matches_unconstrained_positive_solution():
    b = np.array([0.02, 0.01])
    S = np.eye(2)
    lam = 1.0
    pi = solve_simplex_qp(b, S, lam=lam, budget=1.0)
    assert np.allclose(pi, b / lam, atol=1e-10)
    assert pi.sum() < 1.0


def test_zero_policy_when_all_excess_returns_nonpositive():
    b = np.array([-0.1, 0.0, -0.2])
    S = np.eye(3)
    pi = solve_simplex_qp(b, S, lam=1.0, budget=1.0)
    assert np.allclose(pi, 0.0)


def test_budget_scaling_and_constraints():
    b = np.array([0.5, 0.3, 0.1])
    A = np.array([[1.0, 0.1, 0.0], [0.1, 1.5, 0.2], [0.0, 0.2, 0.8]])
    pi = solve_simplex_qp(b, A, lam=0.4, budget=0.6)
    assert np.all(pi >= -1e-10)
    assert pi.sum() <= 0.6 + 1e-8
    # Check the returned point is at least as good as zero and feasible.
    assert objective(pi, b, A, 0.4) >= -1e-10
