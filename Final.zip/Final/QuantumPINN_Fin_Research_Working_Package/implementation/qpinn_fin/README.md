# qpinn_fin — constraint-consistent QPINN for the constrained Merton HJB (first release)

Layout: `qpinn_fin/{config,reference,hjb,models,trainer,evaluate}.py`, `experiments/{run,summarize}.py`, `tests/`.
Run tests: `python -m pytest tests -q`. Pilot: `python -m experiments.run --problems P0 P1 --seeds 0 --steps 1500`;
summarise: `python -m experiments.summarize results/pilot.jsonl`.

Methods: B1 MLP+penalty, B2 MLP+constraint-consistent, B3 circuit without entanglers (+cc), B4 circuit+penalty,
B5 circuit+cc (proposed). Reference: closed form (P0), finite differences (P1, cached in `reference_cache/`).

Known limits of this release
- The circuit is a data re-uploading stand-in, NOT Wang et al.'s tensor-rank circuit.
- P2, entangler-structure ablation, noise study, 30-seed statistics are not included yet.
- `raw_violation_frac` measures the unclipped maximiser; it is meaningless for cc methods (they never use it).
- Quantum runs are ~25x slower per step than the MLP (classically simulated 4 qubits).
