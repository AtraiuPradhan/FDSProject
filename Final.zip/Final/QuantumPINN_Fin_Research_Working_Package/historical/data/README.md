The raw historical dataset is not embedded in this archive because the execution environment could not resolve external hosts during this run. Fetch it reproducibly with:

```bash
python historical/download_french_daily.py
```

The downloader uses the official Kenneth R. French Data Library URL, saves the original ZIP, writes a normalized CSV, and records the SHA-256 hash and coverage in `DATA_PROVENANCE.txt`. Do not replace the source with synthetic or hand-entered observations.
