#!/usr/bin/env python3
"""Walk-forward historical evaluation for the existing single-risky-asset P1 HJB.

All parameter estimates use only the trailing training window. Each test year starts
with normalized wealth 1 and terminal floor F=0.3. Policies are rebalanced monthly;
turnover costs are charged on changes in the risky-asset weight. This is a historical
model-risk study, not a claim of a guaranteed floor or investment advice.

Run from any directory, e.g.:
  python historical/download_french_daily.py
  python historical/walk_forward_backtest.py --first-test-year 2000 --last-test-year 2025 --steps 500
"""
from __future__ import annotations
import argparse, json, sys, time
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent / "implementation" / "qpinn_fin"
sys.path.insert(0, str(PROJECT))
import torch
from qpinn_fin.config import Params
from qpinn_fin.trainer import train
from qpinn_fin.hjb import derivs, policy_raw
from qpinn_fin.reference import solve_fd

TRADING_DAYS = 252


def estimate_params(train_df: pd.DataFrame, gamma: float, floor: float, cmin: float, cmax: float) -> Params:
    # Data are decimal daily returns. Mkt-RF and RF are the official French series.
    excess = train_df["mkt_rf"].to_numpy(dtype=float)
    rf = train_df["rf"].to_numpy(dtype=float)
    market_total = train_df["market_total"].to_numpy(dtype=float)
    r = float(np.mean(rf) * TRADING_DAYS)
    mu = float(r + np.mean(excess) * TRADING_DAYS)
    sigma = float(np.std(market_total, ddof=1) * np.sqrt(TRADING_DAYS))
    sigma = max(sigma, 0.03)  # guard against a degenerate window; disclose in metadata
    return Params(mu=mu, r=r, sigma=sigma, gamma=gamma, T=1.0, F=floor, cmin=cmin, cmax=cmax)


def model_policy(model, p: Params, c: float, t: float) -> float:
    c0 = float(np.clip(c, p.cmin, p.cmax))
    t0 = float(np.clip(t, 0.0, p.T))
    ct = torch.tensor([c0], dtype=torch.float64)
    tt = torch.tensor([t0], dtype=torch.float64)
    _, _, vc, vcc, cl, tl = derivs(model, ct, tt, create_graph=False)
    pi = policy_raw(vc, vcc, cl, tl, p).detach().cpu().numpy().reshape(-1)[0]
    if not np.isfinite(pi):
        return float(np.clip(p.merton_fraction * c0 / (c0 + p.F*np.exp(-p.r*(p.T-t0))), 0, 1))
    return float(np.clip(pi, 0.0, 1.0))


def fd_policy(sol, c: float, t: float) -> float:
    return fd_fields(sol, c, t)[1]


def fd_fields(sol, c: float, t: float):
    """Linearly interpolate FD value and policy in time and log-cushion space."""
    c0 = float(np.clip(c, sol.c[0], sol.c[-1]))
    t0 = float(np.clip(t, sol.t[0], sol.t[-1]))
    j = int(np.searchsorted(sol.t, t0, side="right"))
    if j <= 0:
        v = np.interp(np.log(c0), sol.x, sol.V[0])
        pi = np.interp(np.log(c0), sol.x, sol.pi[0])
        return float(v), float(np.clip(pi, 0, 1))
    if j >= len(sol.t):
        v = np.interp(np.log(c0), sol.x, sol.V[-1])
        pi = np.interp(np.log(c0), sol.x, sol.pi[-1])
        return float(v), float(np.clip(pi, 0, 1))
    lo, hi = j - 1, j
    frac = (t0 - sol.t[lo]) / max(sol.t[hi] - sol.t[lo], 1e-12)
    vlo = np.interp(np.log(c0), sol.x, sol.V[lo]); vhi = np.interp(np.log(c0), sol.x, sol.V[hi])
    plo = np.interp(np.log(c0), sol.x, sol.pi[lo]); phi = np.interp(np.log(c0), sol.x, sol.pi[hi])
    return float((1-frac)*vlo + frac*vhi), float(np.clip((1-frac)*plo + frac*phi, 0, 1))


def model_policy_grid(model, p: Params, c_values: np.ndarray, t: float) -> tuple[np.ndarray, np.ndarray]:
    c0 = np.clip(np.asarray(c_values, dtype=float), p.cmin, p.cmax)
    ct = torch.tensor(c0, dtype=torch.float64)
    tt = torch.full_like(ct, float(np.clip(t, 0.0, p.T)))
    V, _, vc, vcc, cl, tl = derivs(model, ct, tt, create_graph=False)
    raw = policy_raw(vc, vcc, cl, tl, p).detach().cpu().numpy().reshape(-1)
    vals = V.detach().cpu().numpy().reshape(-1)
    return vals, np.clip(raw, 0.0, 1.0)


def evaluate_model_on_fd_grid(model, p: Params, sol, n_c: int = 64, n_t: int = 12) -> dict:
    """Numerical policy/value approximation errors on an independent log-cushion/time grid."""
    c_values = np.geomspace(p.cmin, p.cmax, n_c)
    t_values = np.linspace(0.0, p.T, n_t, endpoint=False)
    vm_all, vr_all, pm_all, pr_all = [], [], [], []
    for t in t_values:
        vm, pm = model_policy_grid(model, p, c_values, float(t))
        fields = [fd_fields(sol, float(c), float(t)) for c in c_values]
        vr = np.asarray([x[0] for x in fields]); pr = np.asarray([x[1] for x in fields])
        vm_all.extend(vm.tolist()); vr_all.extend(vr.tolist()); pm_all.extend(pm.tolist()); pr_all.extend(pr.tolist())
    vm_all = np.asarray(vm_all); vr_all = np.asarray(vr_all)
    pm_all = np.asarray(pm_all); pr_all = np.asarray(pr_all)
    rel_value = np.sqrt(np.mean(((vm_all-vr_all)/np.maximum(np.abs(vr_all), 1e-10))**2))
    abs_policy = np.abs(pm_all-pr_all)
    switching = (pr_all > 0.02) & (pr_all < 0.98)
    return {
        "value_rel_l2_fd_grid": float(rel_value),
        "policy_rmse_fd_grid": float(np.sqrt(np.mean(abs_policy**2))),
        "policy_mae_fd_grid": float(np.mean(abs_policy)),
        "switching_grid_points": int(switching.sum()),
        "policy_rmse_switching_region": float(np.sqrt(np.mean(abs_policy[switching]**2))) if switching.any() else float("nan"),
        "reference_policy_interior_fraction": float(switching.mean()),
    }

def metrics(net_returns: np.ndarray, rf: np.ndarray, wealth_path: np.ndarray, turnover: float, cost_paid: float,
            floor_breach: bool, ood_frac: float) -> dict:
    n = len(net_returns)
    total = float(wealth_path[-1])
    cagr = float(total ** (TRADING_DAYS / max(n, 1)) - 1) if total > 0 else float("nan")
    vol = float(np.std(net_returns, ddof=1) * np.sqrt(TRADING_DAYS)) if n > 1 else float("nan")
    excess = net_returns - rf[:n]
    sd = np.std(excess, ddof=1) if n > 1 else 0.0
    sharpe = float(np.mean(excess) / sd * np.sqrt(TRADING_DAYS)) if sd > 1e-12 else float("nan")
    peak = np.maximum.accumulate(wealth_path)
    dd = wealth_path / np.maximum(peak, 1e-12) - 1
    return {
        "terminal_wealth": total, "cagr": cagr, "annualized_volatility": vol, "sharpe_vs_rf": sharpe,
        "max_drawdown": float(np.min(dd)), "turnover_abs_weight": float(turnover),
        "transaction_cost_fraction_initial_wealth": float(cost_paid),
        "terminal_floor_breach": bool(floor_breach), "state_out_of_domain_fraction": float(ood_frac)
    }


def simulate(test_df: pd.DataFrame, p: Params, strategy: str, policy_fn, rebalance_days: int, cost_rate: float, save_path: bool = True) -> dict:
    wealth = 1.0
    risky_weight = 0.0  # begin in cash; initial allocation incurs cost
    wealth_path = [wealth]
    daily_returns, rf_daily = [], []
    turnover = 0.0; cost_paid = 0.0; ood = 0; rebals = 0
    path_rows = []
    dates = test_df["date"].to_numpy() if "date" in test_df.columns else np.arange(len(test_df))
    mkt = test_df["market_total"].to_numpy(dtype=float)
    rf = test_df["rf"].to_numpy(dtype=float)
    for i, (rm, rr) in enumerate(zip(mkt, rf)):
        wealth_at_day_start = wealth
        t = min(i / TRADING_DAYS, p.T - 1/TRADING_DAYS)
        floor_now = p.F * np.exp(-p.r * (p.T - t))
        c_raw = wealth - floor_now
        if c_raw < p.cmin or c_raw > p.cmax:
            ood += 1
        c = float(np.clip(c_raw, p.cmin, p.cmax))
        is_rebalance = (i % rebalance_days == 0)
        target_weight = float("nan")
        cost_amount = 0.0
        weight_before_trade = risky_weight
        if is_rebalance:
            if strategy == "constant_merton_no_floor":
                target = float(np.clip(p.merton_fraction, 0, 1))
            elif strategy == "fixed_50":
                target = 0.5
            elif strategy == "market_100":
                target = 1.0
            elif strategy == "cash_0":
                target = 0.0
            else:
                target = float(policy_fn(c, t))
            target_weight = target
            trade = abs(target - risky_weight)
            cost = cost_rate * trade
            cost_amount = wealth * cost
            wealth = max(wealth - cost_amount, 0.0)
            cost_paid += cost_amount  # accumulated costs in initial-wealth units
            turnover += trade; rebals += 1
            risky_weight = target
        port_ret = risky_weight * rm + (1.0 - risky_weight) * rr
        weight_during_day = risky_weight
        wealth *= max(1.0 + port_ret, 1e-12)
        net_daily_return = wealth / max(wealth_at_day_start, 1e-12) - 1.0
        daily_returns.append(net_daily_return)
        rf_daily.append(rr)
        wealth_path.append(wealth)
        # Drift risky weight after the daily market/cash returns.
        denom = 1.0 + port_ret
        if denom > 1e-12:
            weight_after_drift = float(np.clip(risky_weight * (1.0 + rm) / denom, 0.0, 1.0))
        else:
            weight_after_drift = risky_weight
        if save_path:
            path_rows.append({
                "date": str(pd.Timestamp(dates[i]).date()) if "date" in test_df.columns else int(dates[i]),
                "strategy": strategy, "wealth_start": wealth_at_day_start,
                "cushion_raw": c_raw, "cushion_clipped": c, "time_years": t,
                "is_rebalance_day": bool(is_rebalance), "weight_before_trade": weight_before_trade,
                "target_weight": target_weight, "weight_during_day": weight_during_day,
                "weight_after_drift": weight_after_drift, "market_return": rm, "risk_free_return": rr,
                "portfolio_return_before_cost": port_ret, "cost_amount": cost_amount,
                "net_daily_return": net_daily_return, "wealth_end": wealth,
                "state_out_of_domain": bool(c_raw < p.cmin or c_raw > p.cmax)
            })
        risky_weight = weight_after_drift
    # The terminal floor is a model target, not guaranteed under parameter error / model mismatch.
    result = metrics(np.asarray(daily_returns), np.asarray(rf_daily), np.asarray(wealth_path), turnover, cost_paid,
                     wealth < p.F, ood / max(len(test_df), 1)) | {"rebalance_count": rebals}
    if save_path:
        result["allocation_path"] = path_rows
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(HERE / "data" / "french_daily_market_rf.csv"))
    ap.add_argument("--out-dir", default=str(HERE / "results"))
    ap.add_argument("--first-test-year", type=int, default=2000)
    ap.add_argument("--last-test-year", type=int, default=2025)
    ap.add_argument("--train-years", type=int, default=5)
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--seeds", nargs="+", type=int, default=[0])
    ap.add_argument("--methods", nargs="+", choices=["B2", "B5"], default=["B2", "B5"])
    ap.add_argument("--max-folds", type=int, default=0, help="0 means all requested years; use 2-3 for a pilot")
    ap.add_argument("--rebalance-days", type=int, default=21)
    ap.add_argument("--cost-bps", type=float, default=10.0)
    ap.add_argument("--gamma", type=float, default=2.0)
    ap.add_argument("--floor", type=float, default=0.30)
    ap.add_argument("--skip-fd", action="store_true")
    ap.add_argument("--fd-nx", type=int, default=240, help="FD spatial grid size; vary to test convergence")
    ap.add_argument("--fd-nt", type=int, default=12000, help="FD time steps; vary to test convergence")
    ap.add_argument("--fd-n-save", type=int, default=40, help="Number of saved FD time slices")
    ap.add_argument("--no-allocation-paths", action="store_true", help="Do not write daily allocation/wealth paths")
    args = ap.parse_args()
    data_path = Path(args.data)
    if not data_path.exists():
        raise SystemExit(f"Historical dataset missing: {data_path}\nRun: python historical/download_french_daily.py")
    df = pd.read_csv(data_path, parse_dates=["date"]).sort_values("date")
    required = {"date", "mkt_rf", "rf", "market_total"}
    if not required.issubset(df.columns):
        raise SystemExit(f"Dataset must contain columns: {sorted(required)}")
    df = df.dropna(subset=["date", "mkt_rf", "rf", "market_total"]).reset_index(drop=True)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    results = []
    allocation_paths = []
    years = list(range(args.first_test_year, args.last_test_year + 1))
    if args.max_folds > 0:
        years = years[:args.max_folds]
    cost_rate = args.cost_bps / 10000.0
    for year in years:
        train_start = pd.Timestamp(year=year-args.train_years, month=1, day=1)
        test_start = pd.Timestamp(year=year, month=1, day=1)
        test_end = pd.Timestamp(year=year+1, month=1, day=1)
        tr = df[(df.date >= train_start) & (df.date < test_start)]
        te = df[(df.date >= test_start) & (df.date < test_end)]
        if len(tr) < 1000 or len(te) < 100:
            print(f"Skipping {year}: insufficient rows train={len(tr)} test={len(te)}")
            continue
        p = estimate_params(tr, args.gamma, args.floor, 0.05, 5.0)
        print(f"Fold {year}: train={tr.date.min().date()}..{tr.date.max().date()} n={len(tr)}; test n={len(te)}; mu={p.mu:.4f}, r={p.r:.4f}, sigma={p.sigma:.4f}, pi_M={p.merton_fraction:.3f}", flush=True)
        policies = {}
        if not args.skip_fd:
            # Lower-resolution FD reference for fold-level policy and backtest comparison.
            sol = solve_fd(p, cap=True, Nx=args.fd_nx, Nt=args.fd_nt, n_save=args.fd_n_save)
            policies["fd_reference"] = lambda c, t, sol=sol: fd_policy(sol, c, t)
        for method in args.methods:
            for seed in args.seeds:
                t0 = time.time()
                model, info = train(method, p, seed=seed, steps=args.steps, n_int=192, n_bd=32, verbose=False)
                key = f"{method}_seed{seed}"
                policies[key] = lambda c, t, model=model, p=p: model_policy(model, p, c, t)
                torch.save(model.state_dict(), out_dir / f"model_{year}_{key}.pt")
                numerical = evaluate_model_on_fd_grid(model, p, sol) if not args.skip_fd else {}
                print(f"  trained {key}: {info['train_time']:.1f}s, params={info['n_params']}, policy_RMSE={numerical.get('policy_rmse_fd_grid', float('nan')):.4g}", flush=True)
                # Save run metadata and optimization history per fold to aid exact reproduction.
                (out_dir / f"model_meta_{year}_{key}.json").write_text(json.dumps({
                    "year": year, "method": method, "seed": seed, "steps": args.steps,
                    "fd_nx": args.fd_nx, "fd_nt": args.fd_nt, "fd_n_save": args.fd_n_save,
                    "n_params": info["n_params"], "train_time_seconds": info["train_time"],
                    "training_history": info["history"],
                    "mu": p.mu, "r": p.r, "sigma": p.sigma, "gamma": p.gamma, "F": p.F,
                    "training_start": str(tr.date.min().date()), "training_end": str(tr.date.max().date()),
                    "test_start": str(te.date.min().date()), "test_end": str(te.date.max().date()),
                    "numerical_comparison": numerical
                }, indent=2))
        strategies = list(policies.keys()) + ["constant_merton_no_floor", "fixed_50", "market_100", "cash_0"]
        for strategy in strategies:
            fn = policies.get(strategy)
            met = simulate(te, p, strategy, fn, args.rebalance_days, cost_rate, save_path=not args.no_allocation_paths)
            path_rows = met.pop("allocation_path", [])
            for path_row in path_rows:
                path_row["test_year"] = year
                path_row["train_start"] = str(tr.date.min().date())
                path_row["train_end"] = str(tr.date.max().date())
                path_row["rebalance_days"] = args.rebalance_days
                path_row["cost_bps"] = args.cost_bps
            allocation_paths.extend(path_rows)
            rec = {"test_year": year, "strategy": strategy, "train_n": len(tr), "test_n": len(te),
                   "mu_est": p.mu, "r_est": p.r, "sigma_est": p.sigma, "merton_fraction_unclipped": p.merton_fraction,
                   "rebalance_days": args.rebalance_days, "cost_bps": args.cost_bps, "steps": args.steps,
                   "seed": int(strategy.split("seed")[-1]) if "seed" in strategy else None, **met}
            if strategy.startswith(("B2_", "B5_")):
                meta_path = out_dir / f"model_meta_{year}_{strategy}.json"
                if meta_path.exists():
                    rec.update(json.loads(meta_path.read_text()).get("numerical_comparison", {}))
            results.append(rec)
            print(f"    {strategy:28s} CAGR={met['cagr']:+.3f} Sharpe={met['sharpe_vs_rf']:+.3f} MDD={met['max_drawdown']:+.3f} floor_breach={met['terminal_floor_breach']}", flush=True)
    if not results:
        raise SystemExit("No folds produced results; verify data coverage and year arguments")
    raw_path = out_dir / "walk_forward_fold_results.csv"
    pd.DataFrame(results).to_csv(raw_path, index=False)
    summary = (pd.DataFrame(results).groupby("strategy").agg(
        folds=("test_year", "nunique"), mean_cagr=("cagr", "mean"), median_cagr=("cagr", "median"),
        mean_sharpe=("sharpe_vs_rf", "mean"), median_sharpe=("sharpe_vs_rf", "median"),
        mean_volatility=("annualized_volatility", "mean"), mean_max_drawdown=("max_drawdown", "mean"),
        floor_breach_rate=("terminal_floor_breach", "mean"), mean_turnover=("turnover_abs_weight", "mean"),
        mean_state_ood_fraction=("state_out_of_domain_fraction", "mean")
    ).reset_index())
    summary_path = out_dir / "walk_forward_summary.csv"
    summary.to_csv(summary_path, index=False)
    print(f"Wrote {raw_path}\nWrote {summary_path}")
    if not args.no_allocation_paths:
        path_path = out_dir / "walk_forward_allocation_paths.csv"
        pd.DataFrame(allocation_paths).to_csv(path_path, index=False)
        print(f"Wrote {path_path}")

if __name__ == "__main__":
    main()
