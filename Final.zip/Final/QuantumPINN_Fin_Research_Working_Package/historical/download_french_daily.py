#!/usr/bin/env python3
"""Download and normalize the official Kenneth French daily factor file.

Source: https://mba.tuck.dartmouth.edu/pages/faculty/Ken.French/data_library.html
The official archive is a ZIP containing daily Fama/French factors in percent.
This script stores the original archive and emits a normalized CSV.
"""
from __future__ import annotations
import argparse, hashlib, io, urllib.request, zipfile
from pathlib import Path
import pandas as pd

URL = "https://mba.tuck.dartmouth.edu/pages/faculty/Ken.French/ftp/F-F_Research_Data_Factors_daily_CSV.zip"


def download(url: str = URL) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "QuantumPINN-Fin research reproduction script"})
    with urllib.request.urlopen(req, timeout=60) as response:
        return response.read()


def parse_zip(blob: bytes) -> pd.DataFrame:
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        names = [n for n in zf.namelist() if n.lower().endswith(".csv") or n.lower().endswith(".txt")]
        if not names:
            raise ValueError("No CSV/TXT member found in the official ZIP")
        raw = zf.read(names[0]).decode("latin-1").splitlines()
    header_idx = None
    for i, line in enumerate(raw):
        normalized = line.replace(" ", "").lower()
        if "mkt-rf" in normalized and "smb" in normalized and "hml" in normalized and "rf" in normalized:
            header_idx = i
            break
    if header_idx is None:
        raise ValueError("Could not locate the Mkt-RF/SMB/HML/RF header in downloaded archive")
    rows = []
    for line in raw[header_idx + 1:]:
        parts = [x.strip() for x in line.split(",")]
        if len(parts) < 5 or not parts[0].isdigit() or len(parts[0]) != 8:
            if rows:
                break
            continue
        try:
            date = pd.to_datetime(parts[0], format="%Y%m%d", errors="raise")
            vals = [float(x) for x in parts[1:5]]
        except (ValueError, TypeError):
            continue
        # Fama/French values are in percent units, not decimal returns.
        rows.append([date, *vals])
    if not rows:
        raise ValueError("No daily observations parsed from official archive")
    df = pd.DataFrame(rows, columns=["date", "mkt_rf_pct", "smb_pct", "hml_pct", "rf_pct"])
    df = df.drop_duplicates("date").sort_values("date").reset_index(drop=True)
    df["market_total_pct"] = df["mkt_rf_pct"] + df["rf_pct"]
    for col in ["mkt_rf_pct", "smb_pct", "hml_pct", "rf_pct", "market_total_pct"]:
        df[col.replace("_pct", "")] = df[col] / 100.0
    return df[["date", "mkt_rf_pct", "rf_pct", "market_total_pct", "mkt_rf", "rf", "market_total"]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default=str(Path(__file__).parent / "data"))
    ap.add_argument("--url", default=URL)
    args = ap.parse_args()
    out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    blob = download(args.url)
    archive = out / "F-F_Research_Data_Factors_daily_CSV.zip"
    archive.write_bytes(blob)
    df = parse_zip(blob)
    csv = out / "french_daily_market_rf.csv"
    df.to_csv(csv, index=False, date_format="%Y-%m-%d")
    digest = hashlib.sha256(blob).hexdigest()
    (out / "DATA_PROVENANCE.txt").write_text(
        "Source: Kenneth R. French Data Library, daily Fama/French factors\n"
        f"Source URL: {args.url}\nSHA-256 of downloaded archive: {digest}\n"
        f"Rows: {len(df)}\nFirst date: {df.date.min().date()}\nLast date: {df.date.max().date()}\n"
        "Unit conversion: source percentages divided by 100 for decimal returns.\n"
        "market_total = (Mkt-RF + RF)/100. RF is the daily risk-free return.\n"
        "Note: historical files may be revised by the provider; retain the archived ZIP for exact reproduction.\n"
    )
    print(f"Wrote {csv} ({len(df)} rows; {df.date.min().date()} to {df.date.max().date()})")
    print(f"SHA-256: {digest}")

if __name__ == "__main__":
    main()
