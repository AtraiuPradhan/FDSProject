# Historical evaluation extension

## Research question

Do the relative policy-approximation accuracy and out-of-sample behavior of the existing classical MLP PINN (B2) and statevector quantum-inspired PINN (B5) persist when HJB parameters are re-estimated from rolling historical market data, including windows where the unconstrained Merton fraction is below zero, between zero and one, or above one?

This is an empirical model-risk study, not a claim of quantum advantage. The model's terminal floor is a target under the calibrated model; it is not guaranteed in historical returns.

## Dataset

Use the official Kenneth R. French Data Library daily Fama/French factors. The downloaded file includes `Mkt-RF` and `RF` in percent. The script preserves the raw ZIP and creates `french_daily_market_rf.csv` with decimal returns:

- `mkt_rf`: daily market excess return
- `rf`: daily risk-free return
- `market_total`: `mkt_rf + rf`

Source: https://mba.tuck.dartmouth.edu/pages/faculty/Ken.French/data_library.html

The research run uses the market portfolio as the single risky asset to match the current single-risky-asset Merton HJB. This avoids inventing a multi-asset extension before it exists in the code. The dataset is historical returns, not price levels. Historical provider data can be revised; retain the ZIP and its SHA-256 digest for reproducibility.

## Reproduce

From the package root:

```bash
python -m pip install numpy pandas torch scipy
python historical/download_french_daily.py
python historical/walk_forward_backtest.py --first-test-year 2000 --last-test-year 2025 --train-years 5 --steps 500 --methods B2 B5 --seeds 0
```

Pilot only (first three test years):

```bash
python historical/walk_forward_backtest.py --first-test-year 2000 --last-test-year 2025 --max-folds 3 --steps 300 --methods B2 B5 --seeds 0
```

The updated script also writes `walk_forward_allocation_paths.csv`, containing each test-day's target allocation (on rebalance days), weight held during the day, post-return drifted weight, costs, returns, cushion state, and wealth. FD grid settings can be varied with `--fd-nx`, `--fd-nt`, and `--fd-n-save`. For example, rerun the same pilot at more than one FD resolution and compare policy/value errors before trusting the reference. Use `--no-allocation-paths` to suppress the daily path file.

Outputs are written to `historical/results/`:
- `walk_forward_fold_results.csv`: one row per strategy and held-out year
- `walk_forward_summary.csv`: summary across held-out years
- `walk_forward_allocation_paths.csv`: daily policy and realized allocation path for debugging
- `model_meta_<year>_<method>_seed<seed>.json`: parameters and training metadata

The finite-difference policy is included by default as a numerical reference for the same estimated parameters. Use `--skip-fd` only for quick software smoke tests, not the final study.

## Protocol

- Each test year uses only the preceding five calendar years to estimate parameters.
- `r` is the annualized mean daily risk-free return; `mu-r` is the annualized mean daily market excess return; `sigma` is annualized standard deviation of market total returns.
- `gamma=2`, horizon `T=1`, terminal floor fraction `F=0.30`, cushion domain `[0.05, 5]` are fixed before the run.
- Strategies: finite-difference reference policy, B2 classical MLP PINN, B5 statevector circuit PINN, constant constrained Merton plug-in (no-floor context baseline), 50% risky, 100% market, and cash.
- Rebalance every 21 trading days and charge 10 basis points on the absolute change in risky weight. Run sensitivity analyses at 0 and 25 bps and 5/21/63-day rebalance intervals before final claims.
- Each held-out year is a normalized one-year episode with initial wealth 1. Summaries should emphasize fold-level distribution (mean/median/worst) rather than treating the independent annual episodes as one continuous wealth path.
- Metrics: annualized return, annualized volatility, Sharpe vs realized risk-free return, maximum drawdown, turnover, transaction costs, terminal floor breach, and fraction of days where cushion lies outside the model's trained domain.
- Model comparisons must be repeated over multiple seeds. Use 30 seeds for the final experiment if compute permits; do not select the best seed.

## Important modeling caveats

1. The HJB assumes constant parameters within each one-year episode. Rolling historical estimates approximate this assumption and are not a predictive model of future parameters.
2. The risk-free rate varies in the historical series, while the HJB uses the training-window mean rate. The floor is therefore a model-based target, not a real-world guarantee.
3. The market portfolio is a broad value-weighted market proxy; it is not an ETF investable-price backtest. The data source reports research returns, not execution prices.
4. The current circuit is a classical statevector simulation and is not the tensor-rank circuit of Wang et al. (2026), nor a QPU experiment.
5. The existing HJB uses a single risky asset. Do not call this a multi-asset portfolio study.
6. No empirical result should be reported until the official dataset has been downloaded, the raw archive hash recorded, and the run completed. This package intentionally contains no fabricated historical metrics.

## Contribution framing

The defensible candidate contribution is a reproducible walk-forward stress test of constraint-aware HJB policy approximation under historically estimated parameter regimes, with regime-correct boundary conditions and explicit transaction-cost/floor-risk diagnostics. This is a narrow empirical contribution; novelty remains conditional on a complete literature review.
