from pathlib import Path
import sys

PROJECT = Path(__file__).resolve().parents[2] / "implementation" / "qpinn_fin"
sys.path.insert(0, str(PROJECT))
from qpinn_fin.config import Params
from qpinn_fin.trainer import boundary_exponents


def test_high_risk_premium_preserves_original_boundary_exponents():
    p = Params(mu=0.10, r=0.03, sigma=0.15, gamma=2.0, T=1.0, F=0.3, cmin=0.05, cmax=5.0)
    lo, hi = boundary_exponents(p)
    assert abs(lo - p.s_unc) < 1e-12
    assert abs(hi - p.s_cap) < 1e-12


def test_subunit_merton_fraction_does_not_force_upper_cap_boundary():
    p = Params(mu=0.06, r=0.03, sigma=0.20, gamma=2.0, T=1.0, F=0.3, cmin=0.05, cmax=5.0)
    assert 0 < p.merton_fraction < 1
    lo, hi = boundary_exponents(p)
    assert abs(lo - p.s_unc) < 1e-12
    assert abs(hi - p.s_unc) < 1e-12


def test_negative_premium_uses_zero_risky_weight_asymptotic():
    p = Params(mu=0.01, r=0.03, sigma=0.20, gamma=2.0, T=1.0, F=0.3, cmin=0.05, cmax=5.0)
    lo, hi = boundary_exponents(p)
    s_zero = (1.0 - p.gamma) * p.kappa(0.0)
    assert abs(lo - s_zero) < 1e-12
    assert abs(hi - s_zero) < 1e-12
