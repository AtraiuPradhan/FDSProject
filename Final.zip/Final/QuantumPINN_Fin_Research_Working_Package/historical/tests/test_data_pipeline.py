import io, zipfile
from pathlib import Path
import sys
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(HERE))
from download_french_daily import parse_zip


def test_parse_official_format_and_percent_conversion():
    raw = (
        "Fama/French Factors\n"
        ",Mkt-RF,SMB,HML,RF\n"
        "19260701, 0.09, -0.25, -0.27, 0.01\n"
        "19260702, -0.12, 0.10, 0.05, 0.01\n"
        "\nAnnual Factors: January-December\n"
    ).encode("latin-1")
    buff = io.BytesIO()
    with zipfile.ZipFile(buff, "w") as zf:
        zf.writestr("factors.csv", raw)
    df = parse_zip(buff.getvalue())
    assert len(df) == 2
    np.testing.assert_allclose(df.loc[0, "market_total"], 0.001, atol=1e-12)
    np.testing.assert_allclose(df.loc[1, "mkt_rf"], -0.0012, atol=1e-12)
    np.testing.assert_allclose(df.loc[0, "rf"], 0.0001, atol=1e-12)


def test_simulation_emits_finite_metrics_and_charges_turnover():
    from walk_forward_backtest import simulate
    from pathlib import Path
    import sys
    project = Path(__file__).resolve().parents[2] / "implementation" / "qpinn_fin"
    sys.path.insert(0, str(project))
    from qpinn_fin.config import Params
    p = Params(mu=0.08, r=0.03, sigma=0.2, gamma=2.0, T=1.0, F=0.3, cmin=0.05, cmax=5.0)
    df = pd.DataFrame({
        "market_total": np.full(42, 0.0004),
        "rf": np.full(42, 0.0001),
    })
    met = simulate(df, p, "fixed_50", None, rebalance_days=21, cost_rate=0.001)
    assert met["rebalance_count"] == 2
    assert met["turnover_abs_weight"] >= 0.5
    assert np.isfinite(met["terminal_wealth"])
    assert np.isfinite(met["cagr"])
