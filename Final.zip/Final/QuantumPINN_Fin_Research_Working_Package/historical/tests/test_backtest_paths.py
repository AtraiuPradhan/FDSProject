from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "historical"))
import walk_forward_backtest as backtest


def test_simulate_records_daily_allocation_path():
    p = SimpleNamespace(r=0.02, F=0.30, cmin=0.05, cmax=5.0, T=1.0, merton_fraction=0.5)
    df = pd.DataFrame({
        "date": pd.to_datetime(["2020-01-02", "2020-01-03", "2020-01-06"]),
        "market_total": [0.01, -0.02, 0.005],
        "rf": [0.0001, 0.0001, 0.0001],
    })
    result = backtest.simulate(df, p, "fixed_50", None, rebalance_days=2, cost_rate=0.001)
    path = result.pop("allocation_path")
    assert len(path) == len(df)
    assert [row["is_rebalance_day"] for row in path] == [True, False, True]
    assert path[0]["target_weight"] == 0.5
    assert np.isnan(path[1]["target_weight"])
    assert all(0.0 <= row["weight_after_drift"] <= 1.0 for row in path)
    assert all("wealth_end" in row and "cost_amount" in row for row in path)


def test_simulate_can_skip_path_recording():
    p = SimpleNamespace(r=0.02, F=0.30, cmin=0.05, cmax=5.0, T=1.0, merton_fraction=0.5)
    df = pd.DataFrame({"market_total": [0.01, -0.02], "rf": [0.0001, 0.0001]})
    result = backtest.simulate(df, p, "cash_0", None, rebalance_days=1, cost_rate=0.0, save_path=False)
    assert "allocation_path" not in result
    assert np.isfinite(result["terminal_wealth"])
